(function(){
	/*绑定事件*/
function observeEvent(el,name,fn){
	if (el.addEventListener) {
      el.addEventListener(name, fn, false);
    } else if (el.attachEvent) {
      el.attachEvent('on' + name, fn);
    }
}
/*样式相关处理的方法*/
function hasClassName(el, cs) {
	return (' '+el.className+' ').indexOf(' '+cs+' ')!=-1;
}
function addClassName(el, cs) {
	if(hasClassName(el, cs))return;
	return el.className = el.className + ' ' + cs;
}
function removeClassName(el, cs) {
	return el.className = el.className.replace(new RegExp('(^|\\s+)'+cs+'(\\s+|$)', 'ig'), ' ');
}
document.getElementsByClassName = function(cls, p) {
	if(p && p.getElementsByClassName) return p.getElementsByClassName(cls);
	var arr = (document.getElementById(p) || document.body).getElementsByTagName('*');
	var rst = [];
	var regExp = new RegExp("(^|\\s)" + cls + "(\\s|$)");
	for(var i=0,n=arr.length;i<n;i++){
		if (arr[i].className.match(regExp))
			rst.push(arr[i]);
	}
	return rst;
}
function findItem(t, cls, attr, aPAttr){
	aPAttr = aPAttr || [];
	while(t!=null&&t.tagName!='BODY'&& t.nodeType==1){
		for (var i = 0; i < aPAttr.length; i++){
			if(dom.getAttribute(aPAttr[i]) != null) return 0;
		}
		if(cls && hasClassName(t, cls))return t;
		if(attr && t.getAttribute(attr, 2)!=null)return t;
		t = t.parentNode;
	}
	return null;
}
function getFileExt(str) { 
	var d=/\.([^\.]+)$/.exec(str);
	return d[1]; 
}
var m_sImageFormats = "bmp|jpg|gif|jpeg";
var m_sVideoFormats = "avi|mov|wmv|flv|rmvb|mp4|3gp";
function bImage(fileext){
	if (m_sImageFormats.toLowerCase().indexOf(fileext.toLowerCase())>=0){
		return true;
	}
	return false;
}
function bVideo(fileext){
	if (m_sVideoFormats.toLowerCase().indexOf(fileext.toLowerCase())>=0){
		return true;
	}
	return false;
}
var m_oPicAppendixes = [];
var m_oVideoAppendixes = [];
function dealcategory(appendix){
	if(appendix.flag == '20'){//20一定是图片附件
		m_oPicAppendixes.push(appendix);
		return;
	}
	if(appendix.flag == '10'){//10是文件附件
		var fileUrl = appendix.url;
		if(!fileUrl || fileUrl == '')
			return;
		var fileExt = getFileExt(fileUrl);
		if(bImage(fileExt)){
			m_oPicAppendixes.push(appendix);
			return;
		}
		if(bVideo(fileExt)){
			m_oVideoAppendixes.push(appendix);
			return;
		} 
	}
}
/*页面元素绑定事件*/
observeEvent(window,'load',function(){
	//正文的过滤
	var contentEl = document.getElementsByClassName('docContent')[0];
	if(contentEl){
		contentEl.innerHTML = contentEl.innerHTML.replace(/\n/img,"<br/>");
	}
	if(appendixes.length == 0)
		return;
	//根据对附件的分类，分为图片类型和视频类型
	for(var i=0;i<appendixes.length;i++){
		var appendix = appendixes[i];
		dealcategory(appendix);
	}
	var appendixbox = document.getElementById('appendixbox');
	var imageEl = appendixbox.getElementsByTagName('img')[0];
	var playBtnEl = appendixbox.getElementsByTagName('span')[0];
	//没有视频类型，显示图片 点击图片，显示原大图
	//如果有视频类型，优先显示视频
	if(m_oVideoAppendixes.length > 0){
		 removeClassName(playBtnEl,'show_null');
		 removeClassName(appendixbox,'show_null');
		 var url = m_oVideoAppendixes[0].url;
		 appendixbox.setAttribute("url",url);//取第一个
		 observeEvent(playBtnEl,'click',function(event){
			//打开视频播放页面，传入文件路径
			var targetUrl = videoUrl + '?src=' + url;
			window.open(targetUrl,'videoplay');
		 });
	}
	if(m_oPicAppendixes.length > 0){
		removeClassName(appendixbox,'show_null');
		if(!appendixbox.getAttribute('url')){
			var url = m_oPicAppendixes[0].srcurl;
			if(!url){
				url = m_oPicAppendixes[0].url;
			}
			appendixbox.setAttribute("url",url);//取第一个
			//图片绑定事件，点击图片，打开原图
			observeEvent(imageEl,'click',function(event){
				window.open(url,'originalpic');
			});
		}
		imageEl.src = m_oPicAppendixes[0].url;
	}
});
})()