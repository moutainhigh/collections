(function(){
	function observeEvent(el,name,fn){
		if (el.addEventListener) {
		  el.addEventListener(name, fn, false);
		} else if (el.attachEvent) {
		  el.attachEvent('on' + name, fn);
		}
	}
	function stopObserving(el, name, fn){
		try{
			if (el.removeEventListener) {
			  el.removeEventListener(name, fn, false);
			} else if (el.detachEvent) {
			  el.detachEvent('on' + name, fn);
			}
		}catch(error){
		}
	}
	document.getElementsByClassName = function(cls, p) {
		if(p && p.getElementsByClassName) return p.getElementsByClassName(cls);
		var arr = (document.getElementById(p) || document.body).getElementsByTagName('*');
		var rst = [];
		var regExp = new RegExp("(^|\\s)" + cls + "(\\s|$)");
		for(var i=0,n=arr.length;i<n;i++){
			if (arr[i].className.match(regExp))
				rst.push(arr[i]);
		}
		return rst;
	}
	//获取文件后缀
	function getFileExt(str) { 
		var d=/\.([^\.]+)$/.exec(str);
		return d[1]; 
	}
	//页面加载完后，绑定事件
	observeEvent(window,'load',function(event){
		//根据当前页面是单独开打的还是嵌入在子页面中来确定是否显示头部
		var headEls = document.getElementsByClassName('header');
		var headEl = null;
		if(headEls != null && headEls.length > 0)
			headEl = headEls[0];
		//获取列表的容器
		var listContainer = document.getElementsByClassName('listcontainer')[0];
		initPage(headEl,listContainer);
		//列表元素绑定事件
		observeEvent(listContainer,'click',function(event){
			event = window.event||event;
			var srcEl = event.srcElement || event.target;
			var targetSrc = findItem(srcEl,'item');
			if(targetSrc != null){
				var docUrl = targetSrc.getAttribute("url");
				var urlExt = getFileExt(docUrl);
				var targetUrl = docUrl.substr(0,docUrl.indexOf("." + urlExt)) + "_page.html?id="+Math.random();
				window.open(targetUrl,'detail');
				return;
			}
			targetSrc = findItem(srcEl,'channelitem');
			if(targetSrc != null){
				var channelUrl = targetSrc.getAttribute("url") + 'index.html?id='+Math.random();
				window.open(channelUrl,'channellist');
				return;
			}
		});
	});
	function initPage(headEl,listContainer){
		if(!headEl || !listContainer)
			return;
		if(window.opener){
			addClassName(listContainer,'listcontainer_singlepage');
			removeClassName(headEl,'show_none');
		}else{
			removeClassName(listContainer,'listcontainer_singlepage');
			addClassName(headEl,'show_none');
		}
	}
	function addClassName(el, cs) {
		if(hasClassName(el, cs))return;
		return el.className = el.className + ' ' + cs;
	}
	function removeClassName(el, cs) {
		return el.className = el.className.replace(new RegExp('(^|\\s+)'+cs+'(\\s+|$)', 'ig'), ' ');
	}
	function findItem(t, cls, attr, aPAttr){
		aPAttr = aPAttr || [];
		while(t!=null&&t.tagName!='BODY'&& t.nodeType==1){
			for (var i = 0; i < aPAttr.length; i++){
				if(dom.getAttribute(aPAttr[i]) != null) return 0;
			}
			if(cls && hasClassName(t, cls))return t;
			if(attr && t.getAttribute(attr, 2)!=null)return t;
			t = t.parentNode;
		}
		return null;
	}
	function hasClassName(el, cs) {
		return (' '+el.className+' ').indexOf(' '+cs+' ')!=-1;
	}
})();