/**
 * 本组件的功能是：鼠标左右拖动来切换图片的显示，图片以数组的形式传入
 */
(function() {
	function observeEvent(el,name,fn){
		if (el.addEventListener) {
		  el.addEventListener(name, fn, false);
		} else if (el.attachEvent) {
		  el.attachEvent('on' + name, fn);
		}
	}
	function stopObserving(el, name, fn){
		try{
			if (el.removeEventListener) {
			  el.removeEventListener(name, fn, false);
			} else if (el.detachEvent) {
			  el.detachEvent('on' + name, fn);
			}
		}catch(error){
		}
	}
	 /*样式相关处理的方法*/
	function hasClassName(el, cs) {
		return (' '+el.className+' ').indexOf(' '+cs+' ')!=-1;
	}
	 function addClassName(el, cs) {
		if(hasClassName(el, cs))return;
		return el.className = el.className + ' ' + cs;
	}
	function removeClassName(el, cs) {
		return el.className = el.className.replace(new RegExp('(^|\\s+)'+cs+'(\\s+|$)', 'ig'), ' ');
	}
	//获取文件后缀
	function getFileExt(str) { 
		var d=/\.([^\.]+)$/.exec(str);
		return d[1]; 
	}
	SwitchImages = function(cfg) {
		this.containerid = cfg.container;
		this.imgUrls = cfg.imgUrls;
		this.descs = cfg.descs;
		this.linkUrl = cfg.linkUrl;
	}
	/*
		width:容器的宽度
		height:容器的高度
		container:容器元素
		size：待切换的图片的个数
		currIndex:当前显示的图片的位置
		lastIndex:上次显示的图片的位置，便于将显示进度的小圆点恢复
		titleHolderEl：底部显示信息的父容器，相当于是创建了可以相对的元素，以便滑动的时候改变显示位置
		showTitleEl：显示标题的元素
	*/
	SwitchImages.prototype = {
		width : 0,
		height:0,
		container : null,
		size : 0,
		currIndex : 0,
		lastIndex : -1,
		titleHolderEl:null,
		showTitleEl : null,
		init:function(){
			var container = document.getElementById(this.containerid);
			if (!container) {
				return;
			}
			//获取父容器的大小
			this.container = container;
			this.container.style.position = 'relative';//为了定位子元素的位置
			var containerwidth = container.offsetWidth;
			var containerheight = container.offsetHeight;
			this.width = containerwidth;
			this.height = containerheight;
			this.size = this.imgUrls.length;
		},
		/** 根据传入的配置信息，渲染图片切换元素*/
		render : function() {
			//初始化
			this.init();
			container = this.container;
			// 产生一个比较长的容器，从而使内部的图片元素在一行显示
			var bigDiv = document.createElement("div");
			bigDiv.className = "switchimgbigcontainer";
			container.appendChild(bigDiv);

			//生成多个img元素
			for(var i=0; i<this.imgUrls.length; i++){
				var imageEl = document.createElement("img");
				imageEl.src = this.imgUrls[i];
				imageEl.className = 'switchimage';
				imageEl.setAttribute("height",this.height);
				imageEl.setAttribute("width",this.width);
				bigDiv.appendChild(imageEl);
			}
			
			//生成底部显示标题和切换位置的背景区域
			var titleHolderEl = document.createElement("div");
			this.titleHolderEl = titleHolderEl;
			titleHolderEl.className = 'topdoctitleholder';
			container.appendChild(titleHolderEl);
			//创建图片标题的显示元素
			var titleEl = document.createElement("div");
			titleEl.className = 'toptitleinfo';
			titleHolderEl.appendChild(titleEl);
			this.showTitleEl = titleEl;
			//生成显示图片切换位置的元素
			var pointContainerEl = document.createElement("div");
			pointContainerEl.className = 'point';
			titleHolderEl.appendChild(pointContainerEl);
			
			//生成多个显示当前位置的图标
			for(var i=0; i<this.imgUrls.length; i++){
				var imageEl = document.createElement("span");
				imageEl.className = 'pointimgflag pointimg';
				pointContainerEl.appendChild(imageEl);
			}
			//鼠标移动图片事件
			this.initEvent();

			//初始化当前显示的元素
			this.changetilteInfo();
		},
		initEvent : function(){
			var context = this;
			var el = this.container;
			observeEvent(el, 'click', function(event){
				//元素的点击事件，打开图片的链接
				event = window.event||event;
				var srcEl = event.srcElement || event.target;
				if(srcEl.className != 'switchimage'){
					return;
				}
				//打开一个新的地址
				var targetLinkUrl = context.linkUrl[context.currIndex];
				if(targetLinkUrl && targetLinkUrl != ''){
					var urlExt = getFileExt(targetLinkUrl);
					var targetUrl = targetLinkUrl.substr(0,targetLinkUrl.indexOf("." + urlExt)) + "_page.html?id="+Math.random();
					window.open(targetUrl,'detail');
				}
			});
			observeEvent(el, 'mousedown', function(event){
				//获取鼠标的初始位置信息
				var ox = event.pageX || event.clientX;
				var drag = function(event){
					//过程中鼠标的目标位置
					var x = event.pageX || event.clientX;
					var movex = ox-x;//差距
					if(movex > 0){//左移
						context.moveLeftImage();
					}
					if(movex < 0){//右移
						context.moveRightImage();
					}
				}
				var dragStop=function(a){
					//处理移动的结果，在此做标题的处理和图片的复位
					if(drag){
						stopObserving(el, 'mousemove', drag, false);
						drag = null;
					}
					if(dragStop){
						stopObserving(el, 'mouseup', dragStop, false);
						dragStop = null;
					}
				};
				observeEvent(el, 'mousemove', drag, false);
				observeEvent(el, 'mouseup', dragStop, false);
				observeEvent(el, 'mouseout', dragStop, false);
			});
		},
		moveLeftImage : function(){
			//如果是向左移，并且已经是最左边的图片在显示，则不移动
			if(this.currIndex==this.size-1)
				return;
			this.container.scrollLeft+=this.width;
			this.lastIndex  = this.currIndex;
			this.currIndex++;
			this.moveTitleInfo(-1);
		},
		moveRightImage : function(){			
			//如果是向右移，并且已经是最右边的图片在显示，则不移动
			if(this.currIndex == 0)
				return;
			this.container.scrollLeft+=-(this.width);
			this.lastIndex  = this.currIndex;
			this.currIndex--;
			this.moveTitleInfo(1);
		},
		moveTitleInfo : function(director){
			//director 1 右移 -1左移
			//alert(this.titleHolderEl.style.left);
			var currLeft = this.titleHolderEl.style.left || 0;
			if(isNaN(currLeft)){
				currLeft = currLeft.substr(0,currLeft.indexOf('px'));
			}
			currLeft = parseInt(currLeft);
			if(director > 0){
				 currLeft-=this.width;
			}else{
				 currLeft+=this.width;
			}
			this.titleHolderEl.style.left = currLeft + 'px';

			//同步修改title信息和小圆点的图片信息
			this.changetilteInfo();
		},
		changetilteInfo : function(){
			this.showTitleEl.innerHTML = this.descs[this.currIndex];
			var titlePointImages = document.getElementsByClassName('pointimgflag');
			removeClassName(titlePointImages[this.currIndex],'pointimg');
			addClassName(titlePointImages[this.currIndex],'currpointimg');
			if(this.lastIndex >= 0){
				removeClassName(titlePointImages[this.lastIndex],'currpointimg');
				addClassName(titlePointImages[this.lastIndex],'pointimg');
			}
		}
	};
})();