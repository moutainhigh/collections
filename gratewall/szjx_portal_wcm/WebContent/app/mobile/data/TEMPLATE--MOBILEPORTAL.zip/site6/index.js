//基础方法
/*绑定事件*/
function observeEvent(el,name,fn){
	if (el.addEventListener) {
      el.addEventListener(name, fn, false);
    } else if (el.attachEvent) {
      el.attachEvent('on' + name, fn);
    }
}
/*样式相关处理的方法*/
function hasClassName(el, cs) {
	return (' '+el.className+' ').indexOf(' '+cs+' ')!=-1;
}
function addClassName(el, cs) {
	if(hasClassName(el, cs))return;
	return el.className = el.className + ' ' + cs;
}
function removeClassName(el, cs) {
	return el.className = el.className.replace(new RegExp('(^|\\s+)'+cs+'(\\s+|$)', 'ig'), ' ');
}
document.getElementsByClassName = function(cls, p) {
	if(p && p.getElementsByClassName) return p.getElementsByClassName(cls);
	var arr = (document.getElementById(p) || document.body).getElementsByTagName('*');
	var rst = [];
	var regExp = new RegExp("(^|\\s)" + cls + "(\\s|$)");
	for(var i=0,n=arr.length;i<n;i++){
		if (arr[i].className.match(regExp))
			rst.push(arr[i]);
	}
	return rst;
}
function findItem(t, cls, attr, aPAttr){
	aPAttr = aPAttr || [];
	while(t!=null&&t.tagName!='BODY'&& t.nodeType==1){
		for (var i = 0; i < aPAttr.length; i++){
			if(dom.getAttribute(aPAttr[i]) != null) return 0;
		}
		if(cls && hasClassName(t, cls))return t;
		if(attr && t.getAttribute(attr, 2)!=null)return t;
		t = t.parentNode;
	}
	return null;
}

/*页面元素绑定事件*/
var currFocusTabEl = null;
observeEvent(window,'load',function(){
	var footerboxEl = document.getElementById('footerbox');
	observeEvent(footerboxEl,'click',footerboxClick);
	observeEvent(footerboxEl,'mouseover',footerboxover);
	observeEvent(footerboxEl,'mouseout',footerboxout);
	//init page info
	currFocusTabEl = document.getElementsByClassName('tabitem')[0];
	var tabUrl = currFocusTabEl.getAttribute("url");
	document.getElementById('contentiframe').src = tabUrl+'index.html?id=' + Math.random();
	addClassName(currFocusTabEl,'tabitemfocus');
});
/*底部tab切换事件*/
function footerboxClick(event){
	var tabitemClickEl = getCurrEventTabItem();
	if(tabitemClickEl == null)
		return;
	//如果标签元素当前选中的就是自己，则返回
	if(hasClassName(tabitemClickEl,'tabitemfocus')){
		return;
	}
	//替换iframe的内容
	//src从元素中的属性获取
	var tabUrl = tabitemClickEl.getAttribute("url");
	var contentIframe = document.getElementById('contentiframe');
	if(tabUrl.indexOf('.htm') > 0 || tabUrl == 'about:blank'){
		contentIframe.src = tabUrl;
	}else{
		contentIframe.src = tabUrl+'index.html?id=' + Math.random();;
	}
	//元素样式的切换
	removeClassName(currFocusTabEl,'tabitemfocus');
	addClassName(tabitemClickEl,'tabitemfocus');
	currFocusTabEl = tabitemClickEl;
}
function footerboxover(event){
	var tabitemOverEl = getCurrEventTabItem(event);
	if(tabitemOverEl == null)
		return;
	addClassName(tabitemOverEl,'tabitemmouseover');
}
function footerboxout(event){
	var tabitemOutEl = getCurrEventTabItem(event);
	if(tabitemOutEl == null)
		return;
	 removeClassName(tabitemOutEl,'tabitemmouseover');
}
function getCurrEventTabItem(event){
	event = window.event || event;
	var srcEl = event.srcElement || event.target;
	if(!hasClassName(srcEl,"tabitem") 
		&& !hasClassName(srcEl,"tabitemimage") 
		&& !hasClassName(srcEl,"tabitemtext")){
		return null;
	}
	var tabitemEl = findItem(srcEl,'tabitem');
	return tabitemEl;
}