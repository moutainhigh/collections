//基础方法
/*绑定事件*/
function observeEvent(el,name,fn){
	if (el.addEventListener) {
      el.addEventListener(name, fn, false);
    } else if (el.attachEvent) {
      el.attachEvent('on' + name, fn);
    }
}
/*样式相关处理的方法*/
function hasClassName(el, cs) {
	return (' '+el.className+' ').indexOf(' '+cs+' ')!=-1;
}
function addClassName(el, cs) {
	if(hasClassName(el, cs))return;
	return el.className = el.className + ' ' + cs;
}
function removeClassName(el, cs) {
	return el.className = el.className.replace(new RegExp('(^|\\s+)'+cs+'(\\s+|$)', 'ig'), ' ');
}
document.getElementsByClassName = function(cls, p) {
	if(p && p.getElementsByClassName) return p.getElementsByClassName(cls);
	var arr = (document.getElementById(p) || document.body).getElementsByTagName('*');
	var rst = [];
	var regExp = new RegExp("(^|\\s)" + cls + "(\\s|$)");
	for(var i=0,n=arr.length;i<n;i++){
		if (arr[i].className.match(regExp))
			rst.push(arr[i]);
	}
	return rst;
}
/*页面元素绑定事件*/
var currFocusNavEl = null;
observeEvent(window,'load',function(){
	//初始化顶部导航元素
	initNavItems();
	var navboxEl = document.getElementById('navbox');
	if(navboxEl != null){
		observeEvent(navboxEl,'click',navboxClick);
	}
	currFocusNavEl = document.getElementsByClassName('navinfo')[0];
	var navurl = currFocusNavEl.getAttribute("url");
	document.getElementById('listiframe').src = navurl+'index.html?id=' + Math.random();
	//元素样式的切换
	addClassName(currFocusNavEl,'navinfofocus');
});
function initNavItems(){
	var bCreateMore = false;
	if(m_oChannels.length >=5)bCreateMore = true;
	var navBox = document.getElementById('navbox');
	for(var i=0;i<m_oChannels.length;i++){
		if(i>3)break;
		var channel = m_oChannels[i];
		var navItem = document.createElement('span');
		navBox.appendChild(navItem);
		if(i==3 && bCreateMore){
			navItem.setAttribute('url',m_sCurrUrl + 'more.html?id='+Math.random());
			navItem.innerHTML = '更多';
		}else{
			navItem.setAttribute('url',channel.url);
			navItem.innerHTML = channel.chnlDesc;
		}
		addClassName(navItem,'navinfo');
	}
}
/*顶部导航切换事件*/
function navboxClick(event){
	event = window.event || event;
	var srcEl = event.srcElement || event.target;
	if(!hasClassName(srcEl,"navinfo")){
		return;
	}
	//如果当前选中的导航就是自己则返回
	if(hasClassName(srcEl,'navinfofocus')){
		return;
	}
	//替换iframe的内容
	//src从元素中的属性获取
	var navurl = srcEl.getAttribute("url");
	document.getElementById('listiframe').src = navurl+'index.html?id=' + Math.random();
	//元素样式的切换
	removeClassName(currFocusNavEl,'navinfofocus');
	addClassName(srcEl,'navinfofocus');
	currFocusNavEl = srcEl;
}