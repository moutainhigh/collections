/*站点全局js*/

//wcm,wcm.apply
(function(){
	
	window.wcm = window.wcm || {};

	wcm.apply = function(d, s) {
		if(!d || !s)return d;
		for (p in s)d[p] = s[p];
		return d;
	}
})();


//wcm.ready
(function(){

	/**运行函数列表*/
	function fireReady(){
		if(!wcm.isReady && wcm.readyEvents){//确保只运行一次
			wcm.isReady = true;
			for (var i = 0; i < wcm.readyEvents.length; i++){
				wcm.readyEvents[i]();
			}
			/**按照W3C标准，把数组的长度设置较小时，末尾的元素都会被清除（清除事件）*/
			wcm.readyEvents.length = 0;
		}
	}

	if (document.addEventListener) {
		document.addEventListener( "DOMContentLoaded", function(){
			document.removeEventListener( "DOMContentLoaded", arguments.callee, false );//清除加载函数
			fireReady();
		}, false );
		window.addEventListener( "load", function(){
			window.removeEventListener( "load", arguments.callee, false );//清除加载函数
			fireReady();
		}, false );
	}else if(window.attachEvent){
		window.attachEvent( "onload", function(){
			window.detachEvent( "onload", arguments.callee, false );//清除加载函数
			fireReady();
		}, false );
	}

	wcm.apply(wcm,  {
		/**只添加事件，如果wcm已经ready，则可以直接运行*/
		ready:function (fn){
			if(wcm.isReady){
				fn();
			}else{
				wcm.readyEvents = wcm.readyEvents || [];
				wcm.readyEvents.push(fn);
			}
		}
	});
})();



//load images
(function(){
	var cacheImgs = null;
	var tryTimes = 0;
	var maxTryTimes = 30;
	var hiddenTryTimes = 5;

	//判断img元素dom是否为合法图片
	function isValidPic(dom){
		var img = new Image();
		img.src = dom.src;
		if(img.width > 0 && img.height > 0){
			return true;
		}
		return false;
	}

	function isValidSrc(_sSrc){
		var img = new Image();
		img.src = _sSrc;
		if(img.width > 0 && img.height > 0){
			return true;
		}
		return false;
	}

	wcm.ready(function(){

		//已经超出了尝试的最大次数
		if(tryTimes >= maxTryTimes){
			for(var index = 0; index < cacheImgs.length; index++){
				var img = cacheImgs[index];
				img.style.display = 'none';
			}
			cacheImgs = null;
			return;
		}
		tryTimes++;

		//记录本次尝试时尚未加载的imgs
		var result = [];
		var imgs = cacheImgs || document.getElementsByTagName("img");

		for(var index = 0; index < imgs.length; index++){
			var img = imgs[index];

			//已经处理过
			if(img.getAttribute('isValid')){
				continue;
			}

			if(!img.getAttribute('_src')){
				img.setAttribute('_src', img.src);
			}		
			
			
			//if(isValidPic(img)){
			if(isValidSrc(img.getAttribute('_src'))){
				img.setAttribute('isValid', '1');
				//强制再触发一次更新
				// CH 为何？？
				//img.src = img.src;
				img.src = img.getAttribute('_src') + "?r=" + (new Date().getTime());
				img.style.display = '';
				continue;
			}else{
				img.src = "{#rootpath}/default.png";
			}

			//尝试多次之后，仍然无效时，先隐藏
			if(hiddenTryTimes <= tryTimes){
				img.style.display = 'none';
			}
			result.push(img);		
		}

		if(result.length > 0){
			cacheImgs = result;
			setTimeout(arguments.callee, 300*tryTimes);
		}
	});
})();	


//click image
(function(){
	
	function imageClicked(event){
		event = window.event || event;

		//非img元素
		var dom = event.target || event.srcElement;
		if(dom.tagName != 'IMG'){
			return;
		}
		
		//解析出文件名
		var sPicName = dom.src;
		var index = sPicName.lastIndexOf('/');
		if(index >= 0){
			sPicName = sPicName.substr(index + 1);
		}
		
		//去掉链接后面的参数
		var index = sPicName.indexOf('?');
		if(index >= 0){
			sPicName = sPicName.substr(0, index);
		}

		//非wcm的图片
		if(sPicName.substr(0,1) != 'W'){
			return;
		}

		//notify client
		if(window.imagestool && window.imagestool.showimages){//android
			window.imagestool.showimages(sPicName);
		}

		//ios
        var myDate = new Date();
	
		location.hash = 'openImage_' + sPicName+'_'+myDate.getMilliseconds();
	} 
	
	if (document.addEventListener) {
		document.addEventListener("click", imageClicked, false);
	}else if(window.attachEvent){
		document.attachEvent( "onclick", imageClicked, false );
	}

})();