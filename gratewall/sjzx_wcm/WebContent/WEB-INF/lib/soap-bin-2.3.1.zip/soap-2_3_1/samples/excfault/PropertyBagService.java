/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.propertybag;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Tests PropertyBagSerializer.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class PropertyBagService {
    /**
     *  "Analyzes" a map.
     */
    public Hashtable analyze(Map map) {
        Hashtable hash = new Hashtable(2);
        Set keySet = map.keySet();
        StringBuffer keys = new StringBuffer(1024);
        for (Iterator i = keySet.iterator(); i.hasNext(); ) {
            if (keys.length() != 0)
                keys.append('~');
            keys.append(i.next().toString());
        }
        hash.put("keys", keys.toString());
        Collection valuesC = map.values();
        StringBuffer values = new StringBuffer(1024);
        for (Iterator i = valuesC.iterator(); i.hasNext(); ) {
            if (values.length() != 0)
                values.append('~');
            values.append(i.next().toString());
        }
        hash.put("values", values.toString());
        return hash;
    }
}
