/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.com.client;

import java.io.*;
import java.net.*;
import java.util.*;

import org.apache.soap.*;
import org.apache.soap.rpc.*;

public class Addit 
{
 public static void main( String[] args) throws Exception
 {

   Integer n1=null;
   Integer n2=null;
   final String urn= "urn:adder-COM";
   if( args.length != 2 ) explain();

   try{
   n1= new Integer( args[0]);
   n2= new Integer( args[1]);
   }catch ( NumberFormatException e)
   {
     explain();
   }


   Vector params = new Vector ();
   params.addElement (new Parameter("n1" , Integer.class,  n1, null)); 
   params.addElement (new Parameter("n2" , Integer.class,  n2, null)); 
  
   URL url = new URL ("http://" + serverhost + ":" + serverport+ soapservlet);

   // Build the call.
   Call call = new Call ();
   call.setTargetObjectURI (urn);
   call.setMethodName ("add");
   call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
   
   call.setParams (params);
   Response resp = call.invoke (/* router URL */ url, /* actionURI */ "" );
   
   if (resp.generatedFault ()) {
     Fault fault = resp.getFault ();

     System.err.println("Generated fault: " + fault);
   } else {
     Parameter result = resp.getReturnValue ();
     System.out.println("The sum of " + args[0] + " and " + args[1] + " is " + result.getValue());
   }
 }
 private static void explain()
 {
   System.err.println("Please provide two integers as inputs to add!");
   System.exit(8);
 }
 static String serverhost= "localhost";
 static String serverport= "8080";
 static String soapservlet= "/soap/servlet/rpcrouter";

} // end  addit
