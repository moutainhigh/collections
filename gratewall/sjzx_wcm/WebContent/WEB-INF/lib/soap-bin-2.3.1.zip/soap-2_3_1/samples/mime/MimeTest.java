/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.mime;

import java.io.*;
import java.util.*;
import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;
import org.apache.soap.*;
import org.apache.soap.util.mime.*;
import org.apache.soap.rpc.SOAPContext;

/**
 * NOTE!!! This service has a *huge* security hole and is provided for
 * demonstration purposes only. Do not leave this service in the classpath
 * of your server!
 *
 * @author Wouter Cloetens (wcloeten@raleigh.ibm.com)
 */
public class MimeTest {
    public MimeTest() {
    }

    public static String sendFile(DataHandler dh) throws IOException {
        StringBuffer sb = new StringBuffer("Received attachment:\n");
        sb.append("Content type: ").append(dh.getContentType());
        sb.append("\nName: ").append(dh.getName());
        Object o = dh.getContent();
        sb.append("\nContent class: ").append(o.getClass().getName());
        sb.append("\nContent: ").append(o.toString());
        return sb.toString();
    }

    public static DataHandler loopFile(DataHandler dh) throws IOException {
        return dh;
    }

    public static Vector getFileVector(String[] fname) throws IOException {
        Vector res = new Vector();

        for (int i = 0; i < fname.length; i++) {
            // Security hole is here:
            DataSource ds = new ByteArrayDataSource(new File(fname[i]), null);
            res.addElement(new DataHandler(ds));
        }
        return res;
    }

    public static Vector loopFileVector(Vector dhs) {
        return dhs;
    }

    public static DataHandler[] getFileArray(String[] fname)
        throws IOException {
        Vector v = getFileVector(fname);
        DataHandler[] dhs = new DataHandler[v.size()];
        for (int i = 0; i < dhs.length; i++)
            dhs[i] = (DataHandler)v.elementAt(i);
        return dhs;
    }

    public static Object[] loopFileArray(Object[] dhs) {
        return dhs;
    }

    public static String listAttachments()
        throws IOException, MessagingException {
            return("Not yet implemented.");
        /*
        // List attachments.
        StringBuffer sb = new StringBuffer("Received attachments:\n");
        MimeBodyPart rootPart = ctx.getRootPart();
        MimeBodyPart bp;
        for (int i = 0; i < ctx.getCount(); i++) {
            bp = (MimeBodyPart)ctx.getBodyPart(i);
            if (bp.equals(rootPart))
                continue;
            sb.append("Content type: ").append(bp.getContentType());
            sb.append("\nContent-ID: ").append(bp.getContentID());
            sb.append("\nContent-Location: ");
            sb.append(bp.getHeader(
                org.apache.soap.Constants.HEADER_CONTENT_LOCATION, null));
            sb.append("\nName: ").append(bp.getFileName());
            Object o = bp.getContent();
            sb.append("\nContent class: ").append(o.getClass().getName());
            if (bp.isMimeType("text/*"))
                sb.append("\nContent: ").append(o.toString()).append('\n');
        }
        return sb.toString();
        */
    }

    /**
     * This is a method for use by Messaging.
     */
    public static void loopProcessor(Envelope env, SOAPContext reqCtx, 
                                                   SOAPContext retCtx)
        throws IOException, MessagingException {
        System.err.println(reqCtx);
        // List attachments.
        StringBuffer sb = new StringBuffer("Received attachments:\n");
        MimeBodyPart rootPart = reqCtx.getRootPart();
        MimeBodyPart bp;
        for (int i = 0; i < reqCtx.getCount(); i++) {
            bp = reqCtx.getBodyPart(i);
            if (bp.equals(rootPart))
                continue;
            sb.append("Content type: ").append(bp.getContentType());
            sb.append("\nContent-ID: ").append(bp.getContentID());
            sb.append("\nContent-Location: ");
            sb.append(bp.getHeader(
                org.apache.soap.Constants.HEADER_CONTENT_LOCATION, null));
            sb.append("\nName: ").append(bp.getFileName());
            Object o = bp.getContent();
            sb.append("\nContent class: ").append(o.getClass().getName());
            if (bp.isMimeType("text/*"))
                sb.append("\nContent: ").append(o.toString()).append('\n');
        }
        System.err.println(sb.toString());
        retCtx.setRootPart(reqCtx.getBodyPart(reqCtx.getCount() - 1));
    }
}
