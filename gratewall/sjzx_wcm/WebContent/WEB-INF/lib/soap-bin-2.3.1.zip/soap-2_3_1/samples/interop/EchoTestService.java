/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.interop;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import org.apache.soap.encoding.Hex;

/** An implementation of the interop echo service as defined at
 * http://www.xmethods.net/ilab.
 * 
 * @author Glen Daniels (gdaniels@macromedia.com)
 */
public class EchoTestService
{
  public void nop()
  {
  }
  
  public int echoInteger(int i)
  {
    return i;
  }

  public float echoFloat(float f)
  {
    return f;
  }
  
  public String echoString(String str)
  {
    return str;
  }
  
  public Data echoStruct(Data data)
  {
    return data;
  }
  
  public int [] echoIntegerArray(int [] ii)
  {
    return ii;
  }
  
  public float [] echoFloatArray(float [] ff)
  {
    return ff;
  }
  
  public String [] echoStringArray(String [] ss)
  {
//Used to debug a user issue
//System.err.println(ss[ss.length - 1]);
    return ss;
  }
  
  public Data [] echoStructArray(Data [] ds)
  {
    return ds;
  }
  
  public void echoVoid()
  {
  }
  
  public byte[] echoBase64(byte[] b64)
  {
    return b64;
  }
  
  public Hex echoHexBinary(Hex bytes)
  {
    return bytes;
  }
  
  public Date echoDate(Date d)
  {
    return d;
  }
  
  public BigDecimal echoDecimal(BigDecimal d)
  {
    return d;
  }
  
  public boolean echoBoolean(boolean b)
  {
    return b;
  }
  
  public Hashtable echoMap(Hashtable map)
  {
    return map;
  }
  
  public Hashtable[] echoMapArray(Hashtable[] mapmap)
  {
    return mapmap;
  }
}
