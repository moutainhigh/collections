echo This test assumes a server URL of http://localhost:8080/soap/servlet/rpcrouter
echo Deploying the excfault service...
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter deploy DeploymentDescriptor.xml
echo 
echo Verify that it\'s there
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter list
echo 
echo Running the excfault test
java samples.excfault.ExcFaultClient http://localhost:8080/soap/servlet/rpcrouter
echo 
echo Running the excfault test with the 1999 schema
java samples.excfault.ExcFaultClient -9 http://localhost:8080/soap/servlet/rpcrouter
echo 
echo Undeploy it now
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter undeploy urn:exc-fault-sample
echo 
echo Verify that it\'s gone
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter list
