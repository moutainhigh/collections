/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.configure;

import java.net.URL;
import java.util.*;
import org.apache.soap.*;
import org.apache.soap.rpc.*;

/**
 * See README for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class GetConfigureParameters {
  public static void main (String[] args) throws Exception {
    if (args.length != 1) {
      System.err.println ("Usage: java " + GetConfigureParameters.class.getName() +
                          " SOAP-router-URL");
      System.exit (1);
    }

    // Process the arguments.
    URL url = new URL(args[0]);

    // Build the call.
    Call call = new Call();
    call.setTargetObjectURI("urn:configure-sample");
    call.setMethodName("getConfigureParameters");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    Vector params = new Vector();
    call.setParams(params);

    // make the call: note that the action URI is empty because the 
    // XML-SOAP rpc router does not need this. This may change in the
    // future.
    Response resp = call.invoke(/* router URL */ url, /* actionURI */ "" );

    // Check the response.
    if (resp.generatedFault()) {
      Fault fault = resp.getFault();
      System.err.println("Generated fault: " + fault);
    } else {
      Parameter result = resp.getReturnValue();
      Hashtable parameters = (Hashtable) result.getValue();
      Enumeration keys = parameters.keys();
      while (keys.hasMoreElements()) {
        String key = (String) keys.nextElement();
        System.out.println(key + " **********************");
        Hashtable p = (Hashtable) parameters.get(key);
        Enumeration ks = p.keys();
        while (ks.hasMoreElements()) {
          String k = (String) ks.nextElement();
          String v = (String) p.get(k);
          System.out.println("  " + k + "=" + v);
        }
      }
    }
  }
}
