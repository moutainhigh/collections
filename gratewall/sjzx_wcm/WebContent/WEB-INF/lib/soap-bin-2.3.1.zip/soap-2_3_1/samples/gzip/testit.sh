echo This test assumes a server URL of http://localhost:8080/soap/servlet/rpcrouter
echo Deploying the gzip service...
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter deploy DeploymentDescriptor.xml
echo 
echo Verify that it\'s there
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter list
echo 
echo Running the gzip test
rm return.dat
java samples.gzip.GzipClient http://localhost:8080/soap/servlet/rpcrouter GzipClient.java return.dat
echo 
echo Undeploy it now
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter undeploy urn:gzip-sample
echo 
echo Verify that it\'s gone
java org.apache.soap.server.ServiceManagerClient http://localhost:8080/soap/servlet/rpcrouter list
