/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.multiref;

import java.io.*;
import java.util.*;
import java.net.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.transport.http.SOAPHTTPConnection;

/**
 * See \samples\multiref\readme for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class GetCircularBean {
  public static void main(String[] args) throws Exception {
    if (args.length != 1) {
      System.err.println("Usage:");
      System.err.println("  java " + GetCircularBean.class.getName() +
                         " SOAP-router-URL");
      System.exit(1);
    }

    URL url = new URL(args[0]);
    SOAPMappingRegistry smr = new SOAPMappingRegistry();
    BeanMultiRefSerializer beanSer = new BeanMultiRefSerializer();

    // Set up debug buffers
    StringBuffer requestBuffer = new StringBuffer(1024);
    StringBuffer responseBuffer = new StringBuffer(1024);
    SOAPHTTPConnection shc = new SOAPHTTPConnection();
    shc.setTimeout(4000);
    shc.setRequestCopy(requestBuffer);
    shc.setResponseCopy(responseBuffer);

    // Map the types.
    smr.mapTypes(Constants.NS_URI_SOAP_ENC,
                 new QName("urn:xml-soap-multiref-sample", "circularbean"),
                 CircularBean.class, beanSer, beanSer);

    // Build the call.
    Call call = new Call();

    call.setSOAPMappingRegistry(smr);
    call.setTargetObjectURI("urn:MultiRefSample");
    call.setMethodName("getCircularBean");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setSOAPTransport(shc);

    Vector params = new Vector();
    call.setParams(params);

    // Invoke the call.
    Response resp;

    try {
      resp = call.invoke(url, "");
    } catch (SOAPException e) {
      System.err.println("Caught SOAPException (" +
                         e.getFaultCode() + "): " +
                         e.getMessage());
      e.printStackTrace(System.err);
      return;
    }

    // Check the response.
    if (!resp.generatedFault()) {
      Parameter ret = resp.getReturnValue();
      Object value = ret.getValue();

      System.out.println(value != null ? value.toString() : "null?");
    } else {
      Fault fault = resp.getFault();

      System.err.println("Generated fault: " + fault);
    }

    // Display the request and response
    System.out.println("********** Request *********");
    System.out.println(shc.getRequestCopy().toString());
    System.out.println("********** Response *********");
    System.out.println(shc.getResponseCopy().toString());
  }
}
