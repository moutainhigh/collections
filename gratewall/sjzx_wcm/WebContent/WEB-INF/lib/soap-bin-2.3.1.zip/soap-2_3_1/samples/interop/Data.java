/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.interop;

class Data
{
  Integer myInt;
  String myString;
  Float myFloat;
  
  public Data()
  {
  }
  
  public Data(int i, String s, float f)
  {
    myInt = new Integer(i);
    myString = s;
    myFloat = new Float(f);
  }
  
  public String toString()
  {
    return "Data[MyInt=" + myInt + ", MyString='" + myString + "', myFloat=" + myFloat + "]";
  }
  
  /**
   * Equality comparison.  
   */
  public boolean equals(Object object) {
    if (!(object instanceof Data)) return false;

    Data that= (Data) object;

    if (!this.myInt.equals(that.myInt)) return false;
    if (!this.myFloat.equals(that.myFloat)) return false;

    if (this.myString == null) {
      if (that.myString != null) return false;
    } else {
      if (!this.myString.equals(that.myString)) return false;
    }

    return true;
  };
}
