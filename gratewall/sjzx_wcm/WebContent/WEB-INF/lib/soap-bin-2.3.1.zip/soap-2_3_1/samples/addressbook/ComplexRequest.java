/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.addressbook;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;

/**
 * See \samples\addressbook\readme for info.
 * Runs GetAddress / PutAddress in cycle in concurrent calls
 * from different threads
 *
 * @author Pavel Ausianik (pavel_ausianik@epam.com)
 */

public class ComplexRequest implements Runnable {

    // Maximum Requests
    public static int maxIterations = 100;
    // Number of supported calls
    public static final int NUM_CALLS = 4;
    public static final int PUT_ADDRESS_0 = 0;
    public static final int GET_ADDRESS_0 = 1;
    public static final int PUT_ADDRESS_1 = 2;
    public static final int GET_ADDRESS_1 = 3;


    // Current request
    public static int currentRequest;
    // Number of running threads
    public static int numberRequests;

    static SOAPMappingRegistry smr = new SOAPMappingRegistry();

    static String encodingStyleURI;
    static URL url;


    Call call;

    ComplexRequest() {
        call = new Call();

        call.setSOAPMappingRegistry(smr);
        call.setTargetObjectURI("urn:AddressFetcher");
        call.setEncodingStyleURI(encodingStyleURI);
    }

    /**
     * Make a Call to an RPC service with desired reqest type
     */
    public void makeCall (int requestType)
            throws SOAPException {
        // Prepare call params
        Vector params = new Vector();
        switch (requestType) {
            case PUT_ADDRESS_0:
                String nameToRegister = "NAME_0 NAME_0";
                Address address = new Address(0, "Street_0", "City_0", "State_0",
                        0, new PhoneNumber(0, "000000", "000000"));
                call.setMethodName("addEntry");

                params.addElement(new Parameter("nameToRegister", String.class,
                                                nameToRegister, null));
                params.addElement(new Parameter("address", Address.class,
                                                address, null));
                call.setParams(params);
                break;

            case PUT_ADDRESS_1:
                nameToRegister = "NAME_1 NAME_1";
                address = new Address(1, "Street_1", "City_1", "State_1",
                        0, new PhoneNumber(01, "111111", "111111"));
                call.setMethodName("addEntry");

                params.addElement(new Parameter("nameToRegister", String.class,
                                                nameToRegister, null));
                params.addElement(new Parameter("address", Address.class,
                                                address, null));
                break;
            case GET_ADDRESS_0:
                String nameToLookup = "NAME_0 NAME_0";
                call.setMethodName("getAddressFromName");

                params.addElement(new Parameter("nameToLookup", String.class,
                                                nameToLookup, null));

                break;
            case GET_ADDRESS_1:
                nameToLookup = "NAME_1 NAME_1";
                call.setMethodName("getAddressFromName");

                params.addElement(new Parameter("nameToLookup", String.class,
                                                nameToLookup, null));

                break;
        }

        call.setParams(params);

        // Invoke the call.
        Response resp = call.invoke(url, "");


        // Check the response.
        if (!resp.generatedFault())
        {
//          System.out.println("Request " + requestType + " has been finished. Thread:" + Thread.currentThread().getName());
        }
        else
        {
          Fault fault = resp.getFault();

          System.err.println("Generated fault: " + fault);
        }
    }

    /**
     * run method of the runnable interface
     * run Thread, until desired number of calls done
     */
    public void run() {
        synchronized (ComplexRequest.class) {
            numberRequests++;
        }
        while (true) {
            try {
                // Get new request type, until available
                int requestType = getNextRequestType();
                if (requestType == -1)
                    break;
                makeCall(requestType);

            }
            catch (SOAPException se)
            {
                // Print and continue running
                se.printStackTrace();
            }
            catch (Throwable e) {
                // Print and stop
                e.printStackTrace();
                break;
            }
        }
        synchronized (ComplexRequest.class) {
            numberRequests--;
        }
    }

    /**
     * returns next request type, shifting it in turn 0-1-2-3
     */
    public synchronized int getNextRequestType() {
        if (currentRequest < maxIterations) {
            return (currentRequest ++) % NUM_CALLS;
        }
        return -1;
    }

    public static void main(String[] args) throws Exception
    {
      if (args.length != 3
          && (args.length != 4 || !args[0].startsWith("-")))
      {
        System.err.println("Usage:");
        System.err.println("  java " + ComplexRequest.class.getName() +
                           " [-encodingStyleURI] SOAP-router-URL NumberOfCalls NumberofThreads");
        System.exit (1);
      }

      // Process the arguments.
      int offset = 4 - args.length;
      encodingStyleURI = args.length == 4
                                ? args[0].substring(1)
                                : Constants.NS_URI_SOAP_ENC;
      url = new URL(args[1 - offset]);
      maxIterations = Integer.parseInt(args[2 - offset]);
      int numThreads = Integer.parseInt(args[3 - offset]);


      smr = new SOAPMappingRegistry();
      BeanSerializer beanSer = new BeanSerializer();

      // Map the types.
      smr.mapTypes(encodingStyleURI,
                   new QName("urn:xml-soap-address-demo", "address"),
                   Address.class, beanSer, beanSer);
      smr.mapTypes(encodingStyleURI,
                   new QName("urn:xml-soap-address-demo", "phone"),
                   PhoneNumber.class, beanSer, beanSer);

      // Fill server registry
      ComplexRequest request = new ComplexRequest();
      request.makeCall(PUT_ADDRESS_0);
      request.makeCall(PUT_ADDRESS_1);

      // Start counting time;
      long time = System.currentTimeMillis();
      Vector threads = new Vector(numThreads);
      for (int i=0; i<numThreads; i++) {
          Thread t = new Thread( new ComplexRequest(), "Run: " + i);
          t.start();
          threads.addElement(t);
      }

      /// Wait for all requests to finish
      for (int i=0; i<numThreads; i++) {
          try {
              ((Thread) threads.elementAt(i)).join();
          } catch (InterruptedException ie) {
          }
      }

      long  time2 = System.currentTimeMillis();
      System.out.println("Time to run " + maxIterations + " requests is " + ((time2-time)/1000.0d) + " sec ");
    }
}

