/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.bidbuy.server.bid;

import samples.bidbuy.shared.*;

/**
 * Big/PurchaseOrder Service
 */
public class BidService {

    static int nextReceiptNumber = 9000;

    /**
     * Request a quote for a given quantity of a specified product
     * @param productName name of product
     * @param quantity number desired
     * @return Total amount in US$ for complete purchase
     */
    public double RequestForQuote(String productName, int quantity) {
        if (quantity < 100) {
           return 1.0 * quantity;
        } if (quantity < 1000) {
           return 0.8 * quantity;
        } else {
           return 0.7 * quantity;
        } 
 
    }

    /**
     * Purchase a given quantity of a specified product
     * @param productName name of product
     * @param quantity number desired
     * @param price desired price (!!!)
     * @param customerId who you are
     * @param shipTo where you want the goods to go
     * @param date where you want the goods to go
     * @return Receipt
     */
    public String SimpleBuy(String address, String productName, int quantity) {
      return "Receipt #" + (nextReceiptNumber++) + '\n' +
             "==============\n" +
             "Quantity=" + quantity + '\n' +
             "Product Name=" + productName + '\n' +
             "Address=" + address + '\n' +
             "Price=$" + RequestForQuote(productName, quantity) + "\n\n" +
             "Courtesy of Apache SOAP";
    }

    /**
     * Process a purchase order.
     * @return Receipt
     */
    public String Buy(PurchaseOrder po) {
      return "Receipt #" + (nextReceiptNumber++) + '\n' +
             "==============\n" + po + "\n\n" +
             "Courtesy of Apache SOAP";
    }

    /**
     * Let the world know that we are still alive...
     */
    public void Ping() {
    }

}
