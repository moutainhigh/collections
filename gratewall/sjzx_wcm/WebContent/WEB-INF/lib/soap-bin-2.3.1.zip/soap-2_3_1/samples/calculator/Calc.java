/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.calculator;

import java.io.*;
import java.net.*;
import java.util.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.rpc.*;

/**
 * A reverse polish notation calc that uses BSF on the server.
 * (some code stolen from the 'gui' calculator example)
 */
public class Calc {
  static int stackSize = 100 ;
  double[]   stack = new double[stackSize];
  String     encodingStyleURI;
  URL        url;

  private void doOp (String op) {
    try {
      // Build the call.
      Call call = new Call ();
      call.setTargetObjectURI ("urn:xml-soap-demo-calculator");
      call.setMethodName (op);
      call.setEncodingStyleURI(encodingStyleURI);
      Vector params = new Vector ();
      double arg2 = pull();
      double arg1 = pull();
  
      params.addElement (new Parameter("arg1", double.class,
                                       new Double (arg1), null));
      params.addElement (new Parameter("arg2", double.class,
                                       new Double (arg2), null));
      call.setParams (params);
  
      // make the call: note that the action URI is empty because the
      // XML-SOAP rpc router does not need this. This may change in the
      // future.
      Response resp = call.invoke (/* router URL */ url, /* actionURI */ "" );
  
      // Check the response.
      if (resp.generatedFault ()) {
        Fault fault = resp.getFault ();

        System.out.println ("Generated fault: " + fault);

        push( 0 );
      } else {
        Parameter result = resp.getReturnValue ();
        push( ((Double)result.getValue()).doubleValue()) ;
      }
    }
    catch( Exception e ) {
      e.printStackTrace();
      push( 0 );
    }
  }

  private double stringToDouble (String s) {
    // try as a double, float or by appending a ".0" to it
    try {
      return Double.valueOf (s).doubleValue ();
    } catch (NumberFormatException e1) {
      try {
        return Float.valueOf (s).floatValue () * 1.0;
      } catch (NumberFormatException e2) {
        if (s.indexOf (".") == -1) {
          return stringToDouble (s + '.' + '0');
        } else {
          return Double.NaN;
        }
      }
    }
  }

  public void push(double val) {
    while ( Double.isNaN(stack[0]) ) pull();
    for ( int i = 99 ; i > 0 ; i-- )
      stack[i] = stack[i-1] ;
   stack[0] = val ;
  }

  public double pull() {
    double result = stack[0] ;
    for ( int i = 0 ; i < 99 ; i++ )
      stack[i] = stack[i+1];
    stack[99] = 0 ; 
    return( result );
  }

  public void printStack() {
    int i ;
    for ( i = 99 ; i > 0 ; i-- )
      if ( stack[i] != 0 ) break ;
    System.out.println( "    Stack:" );
    for(  ; i >= 0 ; i-- )
      System.out.println( "    " + stack[i] );
    System.out.println( "" );
  }

  static String line = null ;
  static int    pos  = 0 ;

  public void setLine(String str) {
    line = str ; 
    pos  = 0 ;
  }

  public String nextToken() {
    // StringTokenizer doesn't handle "2*" nicely, it wants "2 *"
    String  res = null ;
    char    ch  ;

    if ( line == null || line.length() == 0 ) return( null );
    for( ; pos < line.length() ; pos++ ) {
      ch = line.charAt( pos );
      if ( Character.isWhitespace(ch) && res == null ) continue ;
      if ( Character.isWhitespace(ch) && res != null ) break ;
      if ( res == null ) res = "" + ch ;
      else {
        if ( Character.isDigit(ch) || ch == '.' ) {
          if ( Character.isDigit(res.charAt(0)) || 
               res.charAt(0) == '-' ||
               res.charAt(0) == '.' ) 
            res += ch ;
          else break ;
        }
        else 
          break ;
      }
    }
    return( res );
  }

  public void help() {
    System.out.println( "" );
    System.out.println( "A very simple reverse polish notation calculator" );
    System.out.println( "Operations allowed:" );
    System.out.println( "  +-/*" );
    System.out.println( "Other commands:" );
    System.out.println( "  p (print stack)" );
    System.out.println( "  q (quit)" );
    System.out.println( "  ? (print this help message)" );
    System.out.println( "" );
  }

  public void go() {
    InputStreamReader reader   = new InputStreamReader( System.in );
    BufferedReader    bReader  = new BufferedReader( reader );
    String            nextWord ;

    for ( int i = 0 ;i < stackSize ; i++ )
      stack[i] = 0 ;

    for ( ;; ) {
      while ( (nextWord = nextToken()) == null ) {
        System.out.println( ">> " + stack[0] );
        try {
          setLine( bReader.readLine() );
        }
        catch( Exception e ) {}
      }
      if ( nextWord.equals("q") ) break ;
      else if ( nextWord.equals("p") ) printStack();
      else if ( nextWord.equals("h") ) help();
      else if ( nextWord.equals("?") ) help();
      else if ( nextWord.equals("+") ) doOp( "plus" );
      else if ( nextWord.equals("-") ) doOp( "minus" );
      else if ( nextWord.equals("*") ) doOp( "times" );
      else if ( nextWord.equals("/") ) doOp( "divide" );
      else
        push( stringToDouble(nextWord) );
    }
  }

  public static void main (String[] args) throws Exception {
    int maxargs = 2;
    if (args.length != (maxargs-1)
        && (args.length != maxargs || !args[0].startsWith ("-"))) {
      System.err.println ("Usage: java " + Calc.class.getName () +
                          " [-encodingStyleURI] SOAP-router-URL");
      System.exit (1);
    }

    Calc c = new Calc();

    int offset = maxargs - args.length;
    c.encodingStyleURI = (args.length == maxargs)
                         ? args[0].substring(1)
                         : Constants.NS_URI_SOAP_ENC;
    c.url = new URL (args[1 - offset]);
    c.go();
  }
}
