/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.ejb;

import java.io.*;
import java.net.*;
import java.util.*;
import org.apache.soap.*;
import org.apache.soap.rpc.*;

public class ejbtest {
  public static void main (String[] args) throws Exception {
    if (args.length != 1 ) {
      System.err.println ("Usage: java " + ejbtest.class.getName () +
                          " SOAP-router-URL");
      System.exit (1);
    }

    // Process the arguments.
    URL url = new URL (args[0]);

    // Build the call.
    Call call = new Call ();
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI ("urn:ejbhello");
    call.setMethodName ("hello");
    Vector params = new Vector ();
    params.addElement (new Parameter("phrase", String.class,
				     "what's your name?", null));
    call.setParams (params);

    // make the call: note that the action URI is empty because the 
    // XML-SOAP rpc router does not need this. This may change in the
    // future.
    Response resp = call.invoke (/* router URL */ url, /* actionURI */ "" );

    // Check the response.
    if (resp.generatedFault ()) {
      Fault fault = resp.getFault ();

      System.err.println("Generated fault: " + fault);
    } else {
      Parameter result = resp.getReturnValue ();
      System.out.println ( "Done. result=" + result.getValue());
    }
  }
}
