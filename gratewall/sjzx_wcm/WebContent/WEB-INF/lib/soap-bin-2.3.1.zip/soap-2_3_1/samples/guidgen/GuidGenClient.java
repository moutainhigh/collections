/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.guidgen;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.transport.http.SOAPHTTPConnection;

/**
 * Client to speak to MS SOAP implemented GUIDGen service at
 * http://www.itfinity.net/soap/guid/details.html
 *
 * @author Sanjiva Weerawarana (sanjiva@watson.ibm.com)
 */
public class GuidGenClient {
  public static final String DEFAULT_SERVICE_URL =
    "http://www.itfinity.net:8080/soap/guid/default.asp";

  public static void main(String[] args) throws Exception {
    String serviceURL = null;
    boolean goodUsage = true;
    String proxyHost = null;
    int proxyPort = -1;

    // parse command line arguments
    for (int i = 0; i < args.length; i++) {
      if ("-p".equalsIgnoreCase(args[i])) {
        goodUsage = false;
        if (args.length > i) {
          i++;
          int pos = args[i].indexOf(':');
          if (pos != -1) {
            try {
              proxyPort = Integer.parseInt(args[i].substring(pos + 1));
              proxyHost = args[i].substring(0, pos);
              goodUsage = true;
            } catch(NumberFormatException nfe) {
            }
          }
        }
      } else if (serviceURL == null)
        serviceURL = args[i];
      else {
        goodUsage = false;
        break;
      }
    }

    if (!goodUsage) {
      System.err.println ("Usage: java samples.guidgen.GuidGenClient " +
                          "[service-URL] [-p <HTTP proxy hostname:port>]");
      System.exit (1);
    }

    if (serviceURL == null)
      serviceURL = DEFAULT_SERVICE_URL;
    URL url = new URL (serviceURL);

    // define deserializers for the return things (without xsi:type)
    SOAPMappingRegistry smr = new SOAPMappingRegistry ();
    StringDeserializer sd = new StringDeserializer ();
    smr.mapTypes (Constants.NS_URI_SOAP_ENC,
                  new QName ("", "Result"), null, null, sd);

    // create the transport and set parameters
    SOAPHTTPConnection st = new SOAPHTTPConnection();
    if (proxyHost != null) {
        st.setProxyHost(proxyHost);
        st.setProxyPort(proxyPort);
    }

    // build the call.
    Call call = new Call ();
    call.setSOAPTransport(st);
    call.setSOAPMappingRegistry (smr);
    call.setTargetObjectURI ("http://www.itfinity.net/soap/guid/guid.xsd");
    call.setMethodName("NextGUID");
    call.setEncodingStyleURI ("http://schemas.xmlsoap.org/soap/encoding/");

    // invoke it
    System.err.println ("Invoking GUID generator service at: ");
    System.err.println ("\t" + serviceURL);
    Response resp;
    try {
      resp = call.invoke (url, DEFAULT_SERVICE_URL);
    } catch (SOAPException e) {
      System.err.println("Caught SOAPException (" +
                         e.getFaultCode () + "): " +
                         e.getMessage ());
      return;
    }

    // check response 
    if (!resp.generatedFault()) {
      Parameter ret = resp.getReturnValue();
      Object value = ret.getValue();

      System.out.println ("Next GUID is: " + value);
    }
    else {
      Fault fault = resp.getFault ();

      System.err.println("Generated fault: " + fault);
    }
  }
}
