/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.gzip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.rpc.*;

/**
 * See README for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class GzipClient {
    public static void main (String[] args) throws Exception {
        if (args.length != 3) {
            System.err.println ("Usage: java " + GzipClient.class.getName() +
                                " SOAP-router-URL file-to-send file-to-receive");
            System.exit(1);
        }

        // Process the arguments.
        URL url = new URL(args[0]);
        String inFileName = args[1];
        String outFileName = args[2];

        // Check that the output file does not exist
        File outFile = new File(outFileName);
        if (outFile.exists())
            throw new Exception("File " + outFileName + " already exists.");

        // Read the file to send
        File inFile = new File(inFileName);
        long inFileLength = inFile.length();
        if (inFileLength > Integer.MAX_VALUE)
            throw new Exception("File " + inFileName + " is too long ("
                                + inFileLength + " bytes). Specify a file <= "
                                + Integer.MAX_VALUE + " bytes.");
        FileInputStream fis = new FileInputStream(inFile);
        byte[] inFileData = new byte[(int) inFileLength];
        int totalbytes = 0;
        int bytes;
        while ((totalbytes < inFileData.length) && (bytes = fis.read(inFileData, totalbytes, inFileData.length - totalbytes)) != -1) {
            totalbytes += bytes;
        }
        fis.close();
        System.out.println(totalbytes + " bytes read from " + inFileName + ".");

        // Build the call.
        SOAPContext ctx = new SOAPContext();
        ctx.setGzip(true);
        Vector params = new Vector();
        params.addElement(new Parameter("data", inFileData.getClass(), inFileData, null));
        Call call = new Call("urn:gzip-sample",
                             "test",
                             params,
                             null,
                             Constants.NS_URI_SOAP_ENC,
                             ctx);
        // Invoke the call and handle the response.
        Response resp = call.invoke(url, "");
        if (resp.generatedFault()) {
            Fault fault = resp.getFault();
            System.err.println("Generated fault: " + fault);
        } else {
            Parameter result = resp.getReturnValue();
            byte[] outFileData = (byte[]) result.getValue();
            FileOutputStream fos = new FileOutputStream(outFileName);
            fos.write(outFileData, 0, outFileData.length);
            fos.close();
            System.out.println(outFileData.length + " bytes written to " + outFileName + ".");
        }
    }
}
