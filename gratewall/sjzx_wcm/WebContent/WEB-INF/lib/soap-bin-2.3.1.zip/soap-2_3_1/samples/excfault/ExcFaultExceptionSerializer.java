/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.excfault;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.apache.soap.Constants;
import org.apache.soap.Envelope;
import org.apache.soap.encoding.soapenc.SoapEncUtils;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.Bean;
import org.apache.soap.util.xml.Deserializer;
import org.apache.soap.util.xml.DOMUtils;
import org.apache.soap.util.xml.NSStack;
import org.apache.soap.util.xml.QName;
import org.apache.soap.util.xml.Serializer;
import org.apache.soap.util.xml.XMLJavaMappingRegistry;

/**
 * Serializes and deserializes an ExcFaultException.
 * 
 * @author Scott Nichol (snichol@computer.org)
 */
public class ExcFaultExceptionSerializer implements Serializer, Deserializer {
  public void marshall(String inScopeEncStyle, Class javaType, Object src,
                       Object context, Writer sink, NSStack nsStack,
                       XMLJavaMappingRegistry xjmr, SOAPContext ctx)
      throws IllegalArgumentException, IOException {

    nsStack.pushScope();

    if (src == null) {
      SoapEncUtils.generateNullStructure(inScopeEncStyle,
                                         javaType,
                                         context,
                                         sink,
                                         nsStack,
                                         xjmr,
                                         ctx);
    } else {
      SoapEncUtils.generateStructureHeader(inScopeEncStyle,
                                           javaType,
                                           context,
                                           sink,
                                           nsStack,
                                           xjmr,
                                           ctx);

      sink.write(Envelope.LINE_SEPARATOR);

      ExcFaultException exc = (ExcFaultException) src;

      nsStack.pushScope();
      int code = exc.getCode();
      xjmr.marshall(Constants.NS_URI_SOAP_ENC, int.class, new Integer(code),
                    "code", sink, nsStack, ctx);
      sink.write(Envelope.LINE_SEPARATOR);
      nsStack.popScope();

      nsStack.pushScope();
      String msg = exc.getMessage();
      if (msg == null) {
          SoapEncUtils.generateNullStructure(Constants.NS_URI_SOAP_ENC,
                                             String.class, "message", sink,
                                             nsStack, xjmr, ctx);
      } else {
          xjmr.marshall(Constants.NS_URI_SOAP_ENC, String.class, msg,
                        "message", sink, nsStack, ctx);
      }
      sink.write(Envelope.LINE_SEPARATOR);
      nsStack.popScope();

      nsStack.pushScope();
      StringWriter sw = new StringWriter(1024);
      PrintWriter pw = new PrintWriter(sw);
      exc.printStackTrace(pw);
      pw.close();
      xjmr.marshall(Constants.NS_URI_SOAP_ENC, String.class, sw.toString(),
                    "stackTrace", sink, nsStack, ctx);
      sink.write(Envelope.LINE_SEPARATOR);
      nsStack.popScope();

      sink.write("</" + context + '>');
    }

    nsStack.popScope();
  }

  public Bean unmarshall(String inScopeEncStyle, QName elementType, Node src,
                         XMLJavaMappingRegistry xjmr, SOAPContext ctx)
    throws IllegalArgumentException {
    Element root = (Element)src;
    if (SoapEncUtils.isNull(root)) {
      return new Bean(ExcFaultException.class, null);
    }

	int code = -1;
	String msg = null;
	String stackTrace = null;

    Element tempEl = DOMUtils.getFirstChildElement(root);
    while (tempEl != null) {
      String declEncStyle = DOMUtils.getAttributeNS(tempEl,
                            Constants.NS_URI_SOAP_ENV, Constants.ATTR_ENCODING_STYLE);
      String actualEncStyle = declEncStyle != null
                  ? declEncStyle
                  : inScopeEncStyle;

      // If it's a local reference, follow it.
      String href = tempEl.getAttribute(Constants.ATTR_REFERENCE);
      Element actualEl = tempEl;
      if (href != null && !href.equals("") && (href.charAt(0) == '#')) {
          href = href.substring(1);
          actualEl = DOMUtils.getElementByID(src.getOwnerDocument().getDocumentElement(),href);
          if (actualEl == null) {
              throw new IllegalArgumentException("No such ID '" + href + "'");
          }
      }
                  
      QName declItemType = SoapEncUtils.getTypeQName(actualEl);
      QName actualItemType = declItemType;

      Bean b = xjmr.unmarshall(actualEncStyle, actualItemType,
                               actualEl, ctx);

      if (actualEl.getLocalName().equals("code")) {
        code = ((Integer) b.value).intValue();
      } else if (actualEl.getLocalName().equals("message")) {
        msg = (String) b.value;
      } else if (actualEl.getLocalName().equals("stackTrace")) {
        stackTrace = (String) b.value;
      } else {
        throw new IllegalArgumentException("Unknown element '" + actualEl.getLocalName() + "'");
      }

      tempEl = DOMUtils.getNextSiblingElement(tempEl);
    }

	ExcFaultException exc = new ExcFaultException(code, msg, stackTrace);
    return new Bean(ExcFaultException.class, exc);
  }

}
