/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.messaging;

import java.util.Vector;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.apache.soap.*;
import org.apache.soap.rpc.SOAPContext;

/**
 * This class receives the PO via a "purchaseOrder" method and does
 * something with it.
 *
 * @author Sanjiva Weerawarana &lt;sanjiva@watson.ibm.com&gt;
 * @author Scott Nichol &lt;snichol@computer.org&gt;
 */
public class POProcessor {
  public void purchaseOrder (Envelope env, SOAPContext reqCtx, 
                                           SOAPContext resCtx)
    throws Exception {

    String orderDate = null;
    Node shipTo = null;
    Node billTo = null;
    Node items = null;

    Body b = env.getBody();
    Vector entries = b.getBodyEntries();
    for (int i = 0; i < entries.size(); i++) {
      Element e = (Element) entries.elementAt(i);
      String nodeName = e.getNodeName();
      if (nodeName.equals("purchaseOrder")) {
        NodeList children = e.getChildNodes();
        for (int j = 0; j < children.getLength(); j++) {
          Node n = children.item(j);
          switch (n.getNodeType()) {
            case Node.ELEMENT_NODE:
              if (n.getNodeName().equals("shipTo"))
                shipTo = n;
              else if (n.getNodeName().equals("billTo"))
                billTo = n;
              else if (n.getNodeName().equals("items"))
                items = n;
              else if (!n.getNodeName().equals("comment"))
                throw new Exception("Unknown element name: " + n.getNodeName());
              break;
            case Node.ATTRIBUTE_NODE:
              if (n.getNodeName().equals("orderDate"))
                orderDate = ((Attr) n).getValue();
              break;
          }
        }
        if (orderDate == null)
          orderDate = e.getAttribute("orderDate");
      }
    }

    if (orderDate == null)
      throw new Exception("No order date specified");
    if (shipTo == null)
      throw new Exception("No ship to specified");
    if (billTo == null)
      throw new Exception("No bill to specified");
    if (items == null)
      throw new Exception("No items specified");

    StringBuffer response = new StringBuffer(1024);
    response.append(Constants.XML_DECL)
            .append("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">")
            .append("<SOAP-ENV:Body>")
            .append("<purchaseOrderResponse xmlns=\"urn:po-processor\">")
            .append("<return>")
            .append("OK thanks, got the PO for orderDate ")
            .append(orderDate)
            .append("; we'll contact you when ready.")
            .append("</return>")
            .append("</purchaseOrderResponse>")
            .append("</SOAP-ENV:Body>")
            .append("</SOAP-ENV:Envelope>");
	
    resCtx.setRootPart(response.toString(), "text/xml");
  }

  public void bustedRequest (Envelope env, SOAPContext reqCtx, 
                                           SOAPContext resCtx)
    throws Exception {
    throw new IllegalArgumentException ("Huh?");
  }
}
