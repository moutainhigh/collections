/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.addressbook;

/**
 * See \samples\addressbook\readme for info.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class Address
{
  private int         streetNum;
  private String      streetName;
  private String      city;
  private String      state;
  private int         zip;
  private PhoneNumber phoneNumber;

  public Address()
  {
  }

  public Address(int streetNum, String streetName, String city, String state,
                 int zip, PhoneNumber phoneNumber)
  {
    this.streetNum = streetNum;
    this.streetName = streetName;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.phoneNumber = phoneNumber;
  }

  public void setStreetNum(int streetNum)
  {
    this.streetNum = streetNum;
  }

  public int getStreetNum()
  {
    return streetNum;
  }

  public void setStreetName(String streetName)
  {
    this.streetName = streetName;
  }

  public String getStreetName()
  {
    return streetName;
  }

  public void setCity(String city)
  {
    this.city = city;
  }

  public String getCity()
  {
    return city;
  }

  public void setState(String state)
  {
    this.state = state;
  }

  public String getState()
  {
    return state;
  }

  public void setZip(int zip)
  {
    this.zip = zip;
  }

  public int getZip()
  {
    return zip;
  }

  public void setPhoneNumber(PhoneNumber phoneNumber)
  {
    this.phoneNumber = phoneNumber;
  }

  public PhoneNumber getPhoneNumber()
  {
    return phoneNumber;
  }

  public String toString()
  {
    return streetNum + " " + streetName + "\n" +
           city + ", " + state + " " + zip + "\n" +
           phoneNumber;
  }
}