/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.addressbook;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;

/**
 * See \samples\addressbook\readme for info.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class PutAddress
{
  public static void main(String[] args) throws Exception 
  {
    if (args.length != 10
        && (args.length != 11 || !args[0].startsWith("-")))
    {
      System.err.println("Usage:");
      System.err.println("  java " + PutAddress.class.getName() +
                         " [-encodingStyleURI] SOAP-router-URL name " +
                         "streetNum streetName city state zip areaCode " +
                         "exchange number");
      System.exit (1);
    }

    // Process the arguments.
    int offset = 11 - args.length;
    String encodingStyleURI = args.length == 11
                              ? args[0].substring(1)
                              : Constants.NS_URI_SOAP_ENC;
    URL url = new URL(args[1 - offset]);
    String nameToRegister = args[2 - offset];
    PhoneNumber phoneNumber = new PhoneNumber(
      Integer.parseInt(args[8 - offset]),
      args[9 - offset],
      args[10 - offset]);
    Address address = new Address(Integer.parseInt(args[3 - offset]),
                                  args[4 - offset],
                                  args[5 - offset],
                                  args[6 - offset],
                                  Integer.parseInt(args[7 - offset]),
                                  phoneNumber);
    SOAPMappingRegistry smr = new SOAPMappingRegistry();
    BeanSerializer beanSer = new BeanSerializer();

    // Map the types.
    smr.mapTypes(Constants.NS_URI_SOAP_ENC,
                 new QName("urn:xml-soap-address-demo", "address"),
                 Address.class, beanSer, beanSer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC,
                 new QName("urn:xml-soap-address-demo", "phone"),
                 PhoneNumber.class, beanSer, beanSer);

    // Build the call.
    Call call = new Call();

    call.setSOAPMappingRegistry(smr);
    call.setTargetObjectURI("urn:AddressFetcher");
    call.setMethodName("addEntry");
    call.setEncodingStyleURI(encodingStyleURI);

    Vector params = new Vector();

    params.addElement(new Parameter("nameToRegister", String.class,
                                    nameToRegister, null));
    params.addElement(new Parameter("address", Address.class,
                                    address, null));
    call.setParams(params);

    // Invoke the call.
    Response resp;

    try
    {
      resp = call.invoke(url, "");
    }
    catch (SOAPException e)
    {
      System.err.println("Caught SOAPException (" +
                         e.getFaultCode() + "): " +
                         e.getMessage());
      return;
    }

    // Check the response.
    if (!resp.generatedFault())
    {
      System.out.println(nameToRegister + " has been added.");
    }
    else
    {
      Fault fault = resp.getFault();

      System.err.println("Generated fault: " + fault);
    }
  }
}