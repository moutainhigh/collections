/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.doclit;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;

/**
 * See \samples\doclit\readme for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class Add {
  public static void main(String[] args) throws Exception {
    if (args.length != 2) {
      System.err.println("Usage:");
      System.err.println("  java " + Add.class.getName() +
                         " number1 number2");
      System.exit(1);
    }

    // Process the arguments.
    String encodingStyleURI = Constants.NS_URI_SOAP_ENC;
    Float number1 = new Float(args[0]);
    Float number2 = new Float(args[1]);

    // Map the types.
    SOAPMappingRegistry smr = new SOAPMappingRegistry();
    FloatDeserializer deser = new FloatDeserializer();
    smr.mapTypes(Constants.NS_URI_SOAP_ENC,
                 new QName("http://www.xml-webservices.net/services/maths", "AddResult"),
                 null, null, deser);

    // Build the call.
    Call call = new Call();
    call.setSOAPMappingRegistry(smr);
    call.setTargetObjectURI("http://www.xml-webservices.net/services/maths");
    call.setMethodName("Add");
    call.setEncodingStyleURI(encodingStyleURI);
    call.getSOAPContext().setDocLitSerialization(true);
    call.getSOAPContext().setQualifyElements(true);

    Vector params = new Vector();
    params.addElement(new Parameter("a", Float.class, number1, null));
    params.addElement(new Parameter("b", Float.class, number2, null));
    call.setParams(params);

    // Invoke the call.
    URL url = new URL("http://www.xml-webservices.net/services/maths/calculator.asmx");
//  For TcpTunnelGui testing.
//    URL url = new URL("http://localhost:81/services/maths/calculator.asmx");
    String soapAction = "http://www.xml-webservices.net/services/maths/Add";
    Response resp;
    try {
      resp = call.invoke(url, soapAction);
    } catch (SOAPException e) {
      System.err.println("Caught SOAPException (" +
                         e.getFaultCode() + "): " +
                         e.getMessage());
      System.err.println(e.toString());
      return;
    }

    // Check the response.
    if (!resp.generatedFault()) {
      Parameter ret = resp.getReturnValue();
      Object value = ret.getValue();
      System.out.println(number1 + "+" + number2 + "=" + (value != null ? value : "null"));
    } else {
      Fault fault = resp.getFault();
      System.err.println("Generated fault: " + fault);
    }
  }
}