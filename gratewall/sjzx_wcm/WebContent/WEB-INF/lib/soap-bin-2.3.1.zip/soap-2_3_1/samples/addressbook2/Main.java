/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.addressbook2;

import java.net.*;
import org.apache.soap.transport.http.*;

/**
 * This class shows how to use the SOAPHTTPConnection's ability to
 * maintain an http session. 
 *
 * @author Sanjiva Weerawarana <sanjiva@watson.ibm.com>
 */
public class Main {
  static String name1 = "Purdue Boilermaker";
  static Address addr1 = new Address (1, "University Drive", 
				      "West Lafayette", "IN", 47907,
				      new Phone (765, "494", "4900"));

  private static void printAddress (Address ad) {
    if (ad == null) {
      System.err.println ("\t[ADDRESS NOT FOUND!]");
      return;
    }
    System.err.println ("\t" + ad.streetNum_Elem + " " + 
			ad.streetName_Elem);
    System.err.println ("\t" + ad.city_Elem + ", " + ad.state_Elem + " " +
			ad.zip_Elem);
    Phone ph = ad.phoneNumber_Elem;
    System.err.println ("\tPhone: (" + ph.areaCode_Elem + ") " +
			ph.exchange_Elem + "-" + ph.number_Elem);
  }

  private static void doit (AddressBookProxy ab) throws Exception {
    System.err.println (">> Storing address for '" + name1 + "'");
    ab.addEntry (name1, addr1);
    System.err.println (">> Querying address for '" + name1 + "'");
    Address resp = ab.getAddressFromName (name1);
    System.err.println (">> Response is:");
    printAddress (resp);
    System.err.println (">> Querying address for '" + name1 + "' again");
    resp = ab.getAddressFromName (name1);
    System.err.println (">> Response is:");
    printAddress (resp);
  }

  public static void main (String[] args) throws Exception {
    URL serviceURL = null;
    SOAPHTTPConnection shc = new SOAPHTTPConnection ();

    if (args.length > 1) {
      System.err.println ("Usage: java " + Main.class.getName () + 
			  " [Service-URL]");
      System.exit (1);
    } else if (args.length == 1) {
      serviceURL = new URL (args[0]);
    }

    System.err.println ("Using proxy without session maintenance.");
    AddressBookProxy ab1 = new AddressBookProxy ();
    if (serviceURL != null) {
      ab1.setEndPoint (serviceURL);
    }
    shc.setMaintainSession (false);
    ab1.setSOAPTransport (shc);
    doit (ab1);

    System.err.println ("\n\nUsing proxy with session maintenance.");
    AddressBookProxy ab2 = new AddressBookProxy ();
    if (serviceURL != null) {
      ab2.setEndPoint (serviceURL);
    }
    shc.setMaintainSession (true);
    ab2.setSOAPTransport (shc);
    doit (ab2);
  }
}
