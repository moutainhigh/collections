/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.collection;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;

/**
 * See \samples\collection\readme for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class CollectionClient {
  private static String getType(URL endpointURL, Call call) {
    Response resp;
    try {
      resp = call.invoke(endpointURL, "");
    } catch (SOAPException e) {
      return "Caught SOAPException (" +
             e.getFaultCode() + "): " +
             e.getMessage();
    }

    // Check the response.
    if (!resp.generatedFault()) {
      Parameter ret = resp.getReturnValue();
      return (String) ret.getValue();
    } else {
      Fault fault = resp.getFault();
      return "Generated fault: " + fault;
    }
  }

  private static void makeCall(URL endpointURL, Call call, Class type, Object value) {
    Vector params = new Vector();
    params.addElement(new Parameter("collection", type, value, null));
    call.setParams(params);
	System.out.println(type.getName() + " returns " + getType(endpointURL, call));
  }

  public static void main(String[] args) throws Exception {
    if (args.length != 1
        && (args.length != 2 || !args[0].startsWith("-"))) {
      System.err.println("Usage:");
      System.err.println("  java " + CollectionClient.class.getName() +
                         " [-encodingStyleURI] SOAP-router-URL");
      System.exit (1);
    }

    // Process the arguments.
    int offset = 2 - args.length;
    String encodingStyleURI = args.length == 2
                              ? args[0].substring(1)
                              : Constants.NS_URI_SOAP_ENC;
    URL url = new URL(args[1 - offset]);

    // Build the call.
    Call call = new Call();

    call.setTargetObjectURI("urn:CollectionService");
    call.setMethodName("getType");
    call.setEncodingStyleURI(encodingStyleURI);

    // Build a Stack to serialize in various ways.
    Stack param = new Stack();
    param.addElement("Mercury");
    param.addElement("Venus");
    param.addElement("Earth");
    param.addElement("Mars");
    param.addElement("Jupiter");
    param.addElement("Saturn");
    param.addElement("Uranus");
    param.addElement("Neptune");
    param.addElement("Pluto");

	makeCall(url, call, Collection.class, param);
	makeCall(url, call, List.class, param);
	makeCall(url, call, Vector.class, param);
	makeCall(url, call, Stack.class, param);

    // Build an ArrayList to serialize in various ways.
    ArrayList param1 = new ArrayList(param);

	makeCall(url, call, ArrayList.class, param1);

    // Build a TreeSet to serialize in various ways.
    TreeSet param2 = new TreeSet(param);

	makeCall(url, call, Set.class, param2);
	makeCall(url, call, SortedSet.class, param2);
	makeCall(url, call, TreeSet.class, param2);

    // Build an HashSet to serialize in various ways.
    HashSet param3 = new HashSet(param);

	makeCall(url, call, HashSet.class, param3);

    // Build a LinkedList to serialize in various ways.
    LinkedList param4 = new LinkedList(param);

	makeCall(url, call, LinkedList.class, param4);

    // Build a Hashtable to serialize in various ways.
    Hashtable param5 = new Hashtable();
    param5.put("Mercury", new Integer(1));
    param5.put("Venus", new Integer(2));
    param5.put("Earth", new Integer(3));
    param5.put("Mars", new Integer(4));
    param5.put("Jupiter", new Integer(5));
    param5.put("Saturn", new Integer(6));
    param5.put("Uranus", new Integer(7));
    param5.put("Neptune", new Integer(8));
    param5.put("Pluto", new Integer(9));

	makeCall(url, call, Map.class, param5);
	makeCall(url, call, Dictionary.class, param5);
	makeCall(url, call, Hashtable.class, param5);

    // Build a HashMap to serialize in various ways.
    HashMap param6 = new HashMap(param5);

	makeCall(url, call, HashMap.class, param6);

    // Build a WeakHashMap to serialize in various ways.
    WeakHashMap param7 = new WeakHashMap(param5);

	makeCall(url, call, WeakHashMap.class, param7);

    // Build a TreeMap to serialize in various ways.
    TreeMap param8 = new TreeMap(param5);

	makeCall(url, call, SortedMap.class, param8);
	makeCall(url, call, TreeMap.class, param8);
  }
}
