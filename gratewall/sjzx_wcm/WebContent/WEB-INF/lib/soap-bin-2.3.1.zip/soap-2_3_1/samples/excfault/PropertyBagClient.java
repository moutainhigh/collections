/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.propertybag;

import java.net.URL;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;
import org.apache.soap.Constants;
import org.apache.soap.Fault;
import org.apache.soap.Header;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.PropertyBagSerializer;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.Response;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.xml.QName;

/**
 * See README for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class PropertyBagClient {
    private static void usage() {
        System.err.println ("Usage: java " + PropertyBagClient.class.getName() +
                            " [-9|-0] SOAP-router-URL");
        System.exit(1);
    }

    public static void main (String[] args) throws Exception {
        // Process the arguments.
        URL url = null;
        String schemaURI = null;
        if (args.length == 1) {
            url = new URL(args[0]);
            schemaURI = Constants.NS_URI_2001_SCHEMA_XSD;
        } else if (args.length == 2) {
            if (args[0].equals("-9"))
                schemaURI = Constants.NS_URI_1999_SCHEMA_XSD;
            else if (args[0].equals("-0"))
                schemaURI = Constants.NS_URI_2000_SCHEMA_XSD;
            else
                usage();
            url = new URL(args[1]);
        } else {
            usage();
        }

        // Create the bag (something that looks like a "book bean"
        Hashtable bag = new Hashtable(7);
        bag.put("AuthorFirstName", "Michael");
        bag.put("AuthorLastName", "Chabon");
        bag.put("Title", "The Amazing Adventures of Kavalier & Clay");
        bag.put("Pages", new Integer(639));
        bag.put("CopyrightYear", new Integer(2000));
        bag.put("Publisher", "Random House");
        bag.put("DateAdded", new Date());

        // Create the mapping
        PropertyBagSerializer ser = new PropertyBagSerializer();
        SOAPMappingRegistry smr = new SOAPMappingRegistry(null, schemaURI);
        smr.mapTypes(Constants.NS_URI_SOAP_ENC,
                     new QName("urn:property-bag-sample", "PropertyBag"),
                     Map.class, ser, null);

        // Build the call.
        Header header = new Header();
        SOAPContext ctx = new SOAPContext();
        ctx.setGzip(false);
        ctx.setDocLitSerialization(false);
        Vector params = new Vector();
        params.addElement(new Parameter("bag", Map.class, bag, null));
        Call call = new Call("urn:property-bag-sample",
                             "analyze",
                             params,
                             header,
                             Constants.NS_URI_SOAP_ENC,
                             ctx);
        call.setSOAPMappingRegistry(smr);

        // Invoke the call and handle the response.
        Response resp = call.invoke(url, "");
        if (resp.generatedFault()) {
            Fault fault = resp.getFault();
            System.err.println("Generated fault: " + fault);
        } else {
            Parameter result = resp.getReturnValue();
            Hashtable hash = (Hashtable) result.getValue();
            System.out.println("keys: " + hash.get("keys"));
            System.out.println("values: " + hash.get("values"));
        }
    }
}
