/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.addressbook;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;

/**
 * See \samples\addressbook\readme for info.
 *
 * @author Matthew J. Duftler (duftler@us.ibm.com)
 */
public class GetAllListings
{
  public static void main(String[] args) throws Exception 
  {
    if (args.length != 1)
    {
      System.err.println("Usage:");
      System.err.println("  java " + GetAllListings.class.getName() +
                         " SOAP-router-URL");
      System.exit (1);
    }

    // Process the arguments.
    URL url = new URL(args[0]);

    // Build the call.
    Call call = new Call();

    call.setTargetObjectURI("urn:AddressFetcher");
    call.setMethodName("getAllListings");
    call.setEncodingStyleURI(Constants.NS_URI_LITERAL_XML);

    // Invoke the call.
    Response resp;

    try
    {
      resp = call.invoke(url, "");
    }
    catch (SOAPException e)
    {
      System.err.println("Caught SOAPException (" +
                         e.getFaultCode() + "): " +
                         e.getMessage());
      return;
    }

    // Check the response.
    if (!resp.generatedFault())
    {
      Parameter ret = resp.getReturnValue();
      Element bookEl = (Element)ret.getValue();

      System.out.println(DOM2Writer.nodeToString(bookEl));
    }
    else
    {
      Fault fault = resp.getFault();

      System.err.println("Generated fault: " + fault);
    }
  }
}