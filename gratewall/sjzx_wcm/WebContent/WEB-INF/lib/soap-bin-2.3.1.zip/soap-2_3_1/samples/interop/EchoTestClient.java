/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.interop;

import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.Hex;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
import java.util.Date;
import java.util.Hashtable;
import java.math.BigDecimal;

/** A quick-and-dirty client for the Interop echo test services as defined
 * at http://www.xmethods.net/ilab.
 * 
 * Defaults to the Apache endpoint, but you can point it somewhere else via
 * the command line:
 * 
 *    EchoTestClient http://some.other.place/
 * 
 * DOES NOT SUPPORT DIFFERENT SOAPACTION URIS YET.
 * 
 * @author Glen Daniels (gdaniels@macromedia.com)
 * @author Sam Ruby (rubys@us.ibm.com)
 */
public class EchoTestClient
{
  SOAPMappingRegistry smr = new SOAPMappingRegistry();

  public static final String DEFAULT_URL = "http://nagoya.apache.org:5089/soap/servlet/rpcrouter";
  public static final String ACTION_URI = "http://soapinterop.org/";
  public static final String OBJECT_URI = "http://soapinterop.org/xsd";
  public Header header = null;
  
  public static void main(String args[])
  {
    URL url = null;

    try {
      if (args.length > 0) {
        url = new URL(args[0]);
      } else {
        url = new URL(DEFAULT_URL);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    EchoTestClient eTest = new EchoTestClient();
    eTest.doWork(url);
  }

  private static boolean equals(Object obj1, Object obj2) {
    if ((obj1==null) || (obj2==null)) return (obj1==obj2);
    if (obj1.equals(obj2)) return true;
    if (obj1 instanceof Date && obj2 instanceof Date)
      if (Math.abs(((Date)obj1).getTime()-((Date)obj2).getTime())<1000)
        return true;
    if (!obj2.getClass().isArray()) return false;
    if (!obj1.getClass().isArray()) return false;
    if (Array.getLength(obj1) != Array.getLength(obj2)) return false;
    for (int i=0; i<Array.getLength(obj1); i++)
      if (!equals(Array.get(obj1,i),Array.get(obj2,i))) return false;
    return true;
  }
  
  public void doWork(URL url)
  {
    IntDeserializer intDser = new IntDeserializer();
    FloatDeserializer floatDser = new FloatDeserializer();
    StringDeserializer stringDser = new StringDeserializer();
    ArraySerializer arraySer = new ArraySerializer();
    DataSerializer dataSer = new DataSerializer();
    Base64Serializer base64Ser = new Base64Serializer();
    DateSerializer dateSer = new DateSerializer();
    DecimalDeserializer decimalSer = new DecimalDeserializer();
    BooleanDeserializer booleanSer = new BooleanDeserializer();
    HexDeserializer hexDser = new HexDeserializer();

    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName(OBJECT_URI, "SOAPStruct"), Data.class, dataSer, dataSer);
    
    Parameter p = new Parameter("inputString", String.class, "Hi there!\n", null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, stringDser);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), String.class, null, stringDser);
    doCall(url, "echoString", p);

    p = new Parameter("inputStringArray", String[].class, new String[]{
                      "First",
                      "Second",
                      "Fifth (just kidding :))",
                      "Fourth",
                      "Last",
                      "<?xml version='1.0' charset='utf-8'?><xml>And some \"XML characters\" to 'escape'</xml>"}, null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, arraySer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), String[].class, null, arraySer);
    doCall(url, "echoStringArray", p);		

    Integer i = new Integer(5);
    p = new Parameter("inputInteger", Integer.class, i, null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, intDser);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Integer.class, null, intDser);
    doCall(url, "echoInteger", p);
    
    p = new Parameter("inputIntegerArray", Integer[].class, new Integer[]{
                      new Integer(5),
                      new Integer(4),
                      new Integer(3),
                      new Integer(2),
                      new Integer(1)}, null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, arraySer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Integer[].class, null, arraySer);
    doCall(url, "echoIntegerArray", p);		
    
    p = new Parameter("inputFloat", Float.class, new Float(55.5), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, floatDser);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Float.class, null, floatDser);
    doCall(url, "echoFloat", p);

    p = new Parameter("inputFloatArray", Float[].class, new Float[]{
                      new Float(5.5),
                      new Float(4.4),
                      new Float(3.3),
                      new Float(2.2),
                      new Float(1.1)}, null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, arraySer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Float[].class, null, arraySer);
    doCall(url, "echoFloatArray", p);		
    
    p = new Parameter("inputStruct", Data.class, new Data(5, "Hola, baby", (float)10.0), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, dataSer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Data.class, null, dataSer);
    doCall(url, "echoStruct", p);

    p = new Parameter("inputStructArray", Data[].class, new Data[]{
                      new Data(5, "cinqo", new Float("5.55555").floatValue()),
                      new Data(4, "quattro", (float)4.4444),
                      new Data(3, "tres", (float)3.333),
                      new Data(2, "duet", (float)2.22),
                      new Data(1, "un", (float)1.1)}, null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, arraySer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Data[].class, null, arraySer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC,
        new QName(OBJECT_URI, "ArrayOfSOAPStruct"),
        Data[].class, arraySer, arraySer);
    doCall(url, "echoStructArray", p);		

/*
 *  Tests Bugzilla 11072
 *
    p = new Parameter("inputStructArray", Data[].class, new Data[]{
                      new Data(-10000, null, new Float("1").floatValue()),
                      }, null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, arraySer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC,
        new QName(OBJECT_URI, "ArrayOfSOAPStruct"),
        Data[].class, arraySer, arraySer);
    doCall(url, "echoStructArray", p);		
 */

    doCall(url, "echoVoid", null);		

    p = new Parameter("inputBase64", byte[].class, "ciao".getBytes(), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, base64Ser);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), byte[].class, null, base64Ser);
    doCall(url, "echoBase64", p);		

    p = new Parameter("inputHexBinary", Hex.class, new Hex("3344"), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, hexDser);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Hex.class, null, hexDser);
    doCall(url, "echoHexBinary", p);		

    p = new Parameter("inputDate", Date.class, new Date(), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, dateSer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Date.class, null, dateSer);
    doCall(url, "echoDate", p);		

    p = new Parameter("inputDecimal", BigDecimal.class, new BigDecimal("3.14159"), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, decimalSer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), BigDecimal.class, null, decimalSer);
    doCall(url, "echoDecimal", p);		

    p = new Parameter("inputBoolean", Boolean.class, new Boolean(true), null);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "return"), null, null, booleanSer);
    smr.mapTypes(Constants.NS_URI_SOAP_ENC, new QName("", "Result"), Boolean.class, null, booleanSer);
    doCall(url, "echoBoolean", p);		

    Hashtable map = new Hashtable();
    map.put("stringKey", new Integer(5));
    map.put(new Date(), "string value");
    p = new Parameter("inputMap", Hashtable.class, map, null);
    doCall(url, "echoMap", p);		

    Hashtable map2 = new Hashtable();
    map.put("this is the second map", new Boolean(true));
    map.put("test", new Float(411));
    p = new Parameter("inputMapArray", Hashtable[].class, new Hashtable [] { map, map2 }, null);
    doCall(url, "echoMapArray", p);
  }
  
  public void doCall(URL url, String methodName, Parameter param)
  {
    try {
      Call call = new Call();
      Vector params = new Vector();
      if (param != null) 
        params.addElement(param);
      call.setSOAPMappingRegistry(smr);
      call.setTargetObjectURI(ACTION_URI);
      call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
      call.setMethodName(methodName);
      call.setParams(params);
      if (header != null)
        call.setHeader(header);
      
      String soapAction = ACTION_URI;
      if (false) {
        soapAction = soapAction + methodName;
      }
      
      call.setTimeout(60000);
      Response resp = call.invoke(url, soapAction);
      
      // check response 
      if (resp.generatedFault()) {
        Fault fault = resp.getFault ();

        System.out.println(methodName + "\t Fault: " + fault);
      } else {
        Parameter ret = resp.getReturnValue();
        Object output = (ret==null) ? null : ret.getValue();
        Object input = (param==null) ? null : param.getValue();

        if (equals(input,output)) {
          System.out.println(methodName + "\t OK");
        } else {
          System.out.println(methodName + "\t Fail: " + output);
        }
      }
      
    } catch (SOAPException se) {
      System.out.println(methodName + "\t Fault: " + se.toString());
    } catch (Exception e) {
      System.out.println(methodName + "\t Exception: " + e);
      e.printStackTrace();
    }
  }
}
