/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.interop;

import java.util.Vector;
import org.apache.soap.*;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;
import java.net.URL;
import org.apache.soap.util.xml.*;
import java.io.*;
import org.w3c.dom.*;
import org.apache.soap.util.*;
import java.lang.reflect.*;
	
public class DataSerializer implements Serializer, Deserializer
{
  public void marshall(String inScopeEncStyle, Class javaType, Object src,
                       Object context, Writer sink, NSStack nsStack,
                       XMLJavaMappingRegistry xjmr, SOAPContext ctx)
    throws IllegalArgumentException, IOException
  {
    if(!javaType.equals(Data.class))
    {
      throw new IllegalArgumentException("Can only serialize Data instances");
    }
    
    Data data = (Data)src;
    
    nsStack.pushScope();
    if(src!=null)
    {
      SoapEncUtils.generateStructureHeader(inScopeEncStyle,
                                           javaType,
                                           context,
                                           sink,
                                           nsStack,
                                           xjmr,
                                           ctx);

      sink.write(StringUtils.lineSeparator);
      
      xjmr.marshall(inScopeEncStyle, Integer.class, data.myInt, "varInt",
                    sink, nsStack, ctx);
      sink.write(StringUtils.lineSeparator);
      xjmr.marshall(inScopeEncStyle, Float.class, data.myFloat, "varFloat",
                    sink, nsStack, ctx);
      sink.write(StringUtils.lineSeparator);
      xjmr.marshall(inScopeEncStyle, String.class, data.myString, "varString",
                    sink, nsStack, ctx);
      sink.write(StringUtils.lineSeparator);
      
      sink.write("</" + context + '>');
    }
    else
    {
      SoapEncUtils.generateNullStructure(inScopeEncStyle,
                                         javaType,
                                         context,
                                         sink,
                                         nsStack,
                                         xjmr,
                                         ctx);
    }
    nsStack.popScope();
  }
  
  public Bean unmarshall(String inScopeEncStyle, QName elementType, Node src,
                         XMLJavaMappingRegistry xjmr, SOAPContext ctx)
    throws IllegalArgumentException
  {
    Element root = (Element)src;
    String name = root.getTagName();

    if (SoapEncUtils.isNull(root))
    {
      return new Bean(Data.class, null);
    }
    
    Data ret = new Data();
    NodeList list = root.getElementsByTagName("varInt");
    if (list == null || list.getLength() == 0) {
      throw new IllegalArgumentException("No 'varInt' Element (deserializing Data struct)");
    }
    Element el = (Element)list.item(0);
    ret.myInt = new Integer(DOMUtils.getChildCharacterData(el));
    
    list = root.getElementsByTagName("varFloat");
    if (list == null || list.getLength() == 0) {
      throw new IllegalArgumentException("No 'varFloat' Element (deserializing Data struct)");
    }
    el = (Element)list.item(0);
    ret.myFloat = new Float(DOMUtils.getChildCharacterData(el));
    
    list = root.getElementsByTagName("varString");
    if (list == null || list.getLength() == 0) {
      throw new IllegalArgumentException("No 'varString' Element (deserializing Data struct)");
    }
    el = (Element)list.item(0);
    if (SoapEncUtils.isNull(el))
      ret.myString = null;
    else
      ret.myString = ((Text)el.getFirstChild()).getData();
    
    return new Bean(Data.class, ret);
  }
}
