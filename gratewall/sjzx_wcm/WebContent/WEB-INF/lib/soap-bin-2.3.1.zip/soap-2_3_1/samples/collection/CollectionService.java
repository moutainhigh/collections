/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.collection;

import java.util.*;

/**
 * @author Scott Nichol (snichol@computer.org)
 */
public class CollectionService {
  public String getType(Collection c) {
    return "Collection";
  }
  public String getType(List l) {
    return "List";
  }
  public String getType(Map m) {
    return "Map";
  }
  public String getType(Set s) {
    return "Set";
  }
  public String getType(SortedMap m) {
    return "SortedMap";
  }
  public String getType(SortedSet s) {
    return "SortedSet";
  }

  public String getType(ArrayList l) {
    return "ArrayList";
  }
  public String getType(Dictionary d) {
    return "Dictionary";
  }
  public String getType(HashMap m) {
    return "HashMap";
  }
  public String getType(HashSet s) {
    return "HashSet";
  }
  public String getType(Hashtable t) {
    return "Hashtable";
  }
  public String getType(LinkedList l) {
    return "LinkedList";
  }
  public String getType(Stack s) {
    return "Stack";
  }
  public String getType(TreeMap m) {
    return "TreeMap";
  }
  public String getType(TreeSet s) {
    return "TreeSet";
  }
  public String getType(Vector v) {
    return "Vector";
  }
  public String getType(WeakHashMap m) {
    return "WeakHashMap";
  }
}
