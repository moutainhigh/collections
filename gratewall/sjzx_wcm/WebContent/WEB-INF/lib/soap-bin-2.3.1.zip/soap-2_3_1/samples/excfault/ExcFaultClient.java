/**
 *
 * Copyright 2000-2004 The Apache Software Foundation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package samples.excfault;

import java.net.URL;
import java.util.Vector;
import org.apache.soap.Constants;
import org.apache.soap.Fault;
import org.apache.soap.Header;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.Response;
import org.apache.soap.rpc.SOAPContext;
import org.apache.soap.util.xml.QName;

/**
 * See README for info.
 *
 * @author Scott Nichol (snichol@computer.org)
 */
public class ExcFaultClient {
    private static void usage() {
        System.err.println ("Usage: java " + ExcFaultClient.class.getName() +
                            " [-9|-0] SOAP-router-URL");
        System.exit(1);
    }

    public static void main (String[] args) throws Exception {
        // Process the arguments.
        URL url = null;
        String schemaURI = null;
        if (args.length == 1) {
            url = new URL(args[0]);
            schemaURI = Constants.NS_URI_2001_SCHEMA_XSD;
        } else if (args.length == 2) {
            if (args[0].equals("-9"))
                schemaURI = Constants.NS_URI_1999_SCHEMA_XSD;
            else if (args[0].equals("-0"))
                schemaURI = Constants.NS_URI_2000_SCHEMA_XSD;
            else
                usage();
            url = new URL(args[1]);
        } else {
            usage();
        }

        // Create the mapping
        ExcFaultExceptionSerializer ser = new ExcFaultExceptionSerializer();
        SOAPMappingRegistry smr = new SOAPMappingRegistry(null, schemaURI);
        smr.mapTypes(Constants.NS_URI_SOAP_ENC,
                     new QName("urn:exc-fault-sample", "ExcFaultException"),
                     ExcFaultException.class, ser, ser);

        // Build the call.
        Header header = new Header();
        SOAPContext ctx = new SOAPContext();
        ctx.setGzip(false);
        ctx.setDocLitSerialization(false);
        Vector params = new Vector();
        Call call = new Call("urn:exc-fault-sample",
                             "throw1",
                             params,
                             header,
                             Constants.NS_URI_SOAP_ENC,
                             ctx);
        call.setSOAPMappingRegistry(smr);

        // Invoke the call and handle the response.
        Response resp = call.invoke(url, "");
        if (resp.generatedFault()) {
            Fault fault = resp.getFault();
            System.err.println("Generated fault: " + fault);
            Vector v = fault.getDetailEntries();
            for (int i = 0; i < v.size(); i++) {
            	Object o = v.elementAt(i);
            	if (o instanceof Parameter) {
            		Parameter p = (Parameter) o;
            		if (p.getType().equals(ExcFaultException.class)) {
            			ExcFaultException exc = (ExcFaultException) p.getValue();
            			System.err.println(" ExcFaultException >>>>>");
            			System.err.println("  Code: " + exc.getCode());
            			System.err.println("  Message: " + exc.getMessage());
            			exc.printStackTrace();
            		}
            	}
            }
        } else {
            Parameter result = resp.getReturnValue();
            Object o = result.getValue();
            System.out.println("return: " + o);
        }
    }
}
