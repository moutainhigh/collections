# 《SpringBoot微信点餐》常见问题

问：关于账号借用问题

答：提问区已经有这个问题了，http://coding.imooc.com/learn/questiondetail/17686.html